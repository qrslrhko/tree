

#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>
#include <time.h>
#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "Shader.h"

const GLuint leaf_WIDTH = 800, leaf_HEIGHT = 600;


glm::vec3 lightPos(2.0f, 0.0f, 0.0f);
//glm::vec3 lightPos(1.2f, 1.0f, 2.0f);

void setUp_leaf_position(Shader LEAF_SHADER ,Model LEAF_MODEL, glm::vec3 TRANSLATION,  bool level_3_ON, GLfloat fov,GLfloat camX, GLfloat camZ, glm::vec3 cameraPos , glm::vec3 cameraFront,glm::vec3 cameraUp ){


    GLint lightPosLoc    = glGetUniformLocation(LEAF_SHADER.Program, "lightPos");
    GLint viewPosLoc     = glGetUniformLocation(LEAF_SHADER.Program, "viewPos");
    //glUniform3f(objectColorLoc, 1.0f, 0.5f, 0.31f);
    //glUniform3f(lightColorLoc,  1.0f, 1.0f, 1.0f);
    glUniform3f(lightPosLoc,    lightPos.x, lightPos.y, lightPos.z);
    
   // glUniform3f(viewPosLoc,     camera.Position.x, camera.Position.y, camera.Position.z);
    glUniform3f(viewPosLoc,  camX , 0.0, camZ);
      
/*
    
    //------------------------
    GLint lightPosLoc    = glGetUniformLocation(LEAF_SHADER.Program, "light.position");
    GLint viewPosLoc     = glGetUniformLocation(LEAF_SHADER.Program, "viewPos");
    glUniform3f(lightPosLoc,    lightPos.x, lightPos.y, lightPos.z);
    glUniform3f(viewPosLoc,  camX , 0.0, camZ);
   
    
    
    //glUniform3f(viewPosLoc,     camera.Position.x, camera.Position.y, camera.Position.z);
    
//    if(level_3_ON == true){
//        
//      //  leaf_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
//        
//        glUniform3f(viewPosLoc, glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0)););
//    }else{
//        leaf_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
//    }
//    
    
    
    
    // Set lights properties
    glm::vec3 lightColor;
    lightColor.x = sin(glfwGetTime() * 2.0f);
    lightColor.y = sin(glfwGetTime() * 0.7f);
    lightColor.z = sin(glfwGetTime() * 1.3f);
    
    //lightColor = vec4(result + 0.419608 ,0.556863, 0.137255,1.0f);
//    lightColor.x =  0.419608f;
//    lightColor.y = 0.556863f;
//    lightColor.z = 0.137255f;
//    
    
    glm::vec3 diffuseColor = lightColor * glm::vec3(0.5f); // Decrease the influence
    glm::vec3 ambientColor = diffuseColor * glm::vec3(0.2f); // Low influence
   // glm::vec3 ambientColor =lightColor * glm::vec3(0.1f); // Low influence

    
    glUniform3f(glGetUniformLocation(LEAF_SHADER.Program, "light.ambient"),  ambientColor.x, ambientColor.y, ambientColor.z);
    glUniform3f(glGetUniformLocation(LEAF_SHADER.Program, "light.diffuse"),  diffuseColor.x, diffuseColor.y, diffuseColor.z);
    glUniform3f(glGetUniformLocation(LEAF_SHADER.Program, "light.specular"), 1.0f, 1.0f, 1.0f);
    // Set material properties
    glUniform3f(glGetUniformLocation(LEAF_SHADER.Program, "material.ambient"),   1.0f, 0.5f, 0.31f);
    glUniform3f(glGetUniformLocation(LEAF_SHADER.Program, "material.diffuse"),   1.0f, 0.5f, 0.31f);
    glUniform3f(glGetUniformLocation(LEAF_SHADER.Program, "material.specular"),  0.5f, 0.5f, 0.5f); // Specular doesn't have full effect on this object's material
    glUniform1f(glGetUniformLocation(LEAF_SHADER.Program, "material.shininess"), 32.0f);

    
    
    
 */
    
    
    
glm::mat4 leaf_projection = glm::perspective(fov, (GLfloat)leaf_WIDTH/(GLfloat)leaf_HEIGHT, 0.1f, 100.0f);
glUniformMatrix4fv(glGetUniformLocation(LEAF_SHADER.Program, "projection"), 1, GL_FALSE, glm::value_ptr(leaf_projection));

glm::mat4 leaf_view;
if(level_3_ON == true){
    
    leaf_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
}else{
    leaf_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
}

glUniformMatrix4fv(glGetUniformLocation(LEAF_SHADER.Program, "view"), 1, GL_FALSE, glm::value_ptr(leaf_view));

// Draw the loaded model
glm::mat4 leaf_model;
// leaf_model = glm::translate(leaf_model, glm::vec3(.3f, .51f, 0.0f));

// leaf_model = glm::translate(leaf_model, glm::vec3(.1f, 0.0f, .1f));

    leaf_model = glm::translate(leaf_model, TRANSLATION);
    
    
    
    // leaf_model = glm::translate(leaf_model, glm::vec3(1, 3.0f, -1.0f));//
leaf_model = glm::scale(leaf_model, glm::vec3(0.005f, 0.01f, 0.009f));
glUniformMatrix4fv(glGetUniformLocation(LEAF_SHADER.Program, "model"), 1, GL_FALSE, glm::value_ptr(leaf_model));

}




