#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>


#define sides 11
#define lev2_little_3_radius 0.02


glm::vec3 lev2_little_3_cone[500];
glm::vec3 lev2_little_3_side_cone[500];

glm::vec3 lev2_little_cone_3[500];
glm::vec3 lev2_little_cone_side_3[500];

GLuint lev2_little_3_VBO,lev2_little_3_VAO;
GLuint lev2_little_3_side_VBO,lev2_little_3_side_VAO;

glm::vec3 lev2_translations_3[100];
GLuint lev2_instance_3_VBO;


int lev2_3_count_side = 0;

void lev2_make_instance_2(){
    
    lev2_translations_3[0].x = .01f;
    lev2_translations_3[0].y = -0.055f;
    lev2_translations_3[0].z = -0.15f;
    


    
    glGenBuffers(1, &lev2_instance_3_VBO);
    glBindBuffer(GL_ARRAY_BUFFER, lev2_instance_3_VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(lev2_translations_3), lev2_translations_3, GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    
}



void little_cone_level_2_3(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    lev2_3_count_side = 0;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    lev2_little_3_cone[0].x = -0.2f;
    lev2_little_3_cone[0].y = 0.6f;
    lev2_little_3_cone[0].z = 0.4f;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = .37f+ outer.z  + lev2_little_3_radius * cos(rad);
        outer.y =  0.58f + outer.y + lev2_little_3_radius * sin(rad);
        outer.x =  -0.1f + outer.x ;
        
        lev2_little_3_cone[idx++] = outer;
        lev2_3_count_side++;
    }
    //
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
    //  printf("idx+2: %d ",idx + 2);
    while (count_cone < lev2_3_count_side) {
        idx = count_cone * 3;
        lev2_little_cone_3[idx+0] = lev2_little_3_cone[0];
        lev2_little_cone_3[idx+1] = lev2_little_3_cone[i];
        lev2_little_cone_3[idx+2] = lev2_little_3_cone[j];
        i++;
        j++;
        count_cone++;
    }
    
    
    little_cone_texture();
    lev2_make_instance_2();
    
    
    glGenVertexArrays(1, &lev2_little_3_VAO);
    glGenBuffers(1,&lev2_little_3_VBO);
    glBindVertexArray(lev2_little_3_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,lev2_little_3_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(lev2_little_cone_3) ,lev2_little_cone_3, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(1);  // texture coords
    glBindBuffer(GL_ARRAY_BUFFER, little_cone_texture_VBO);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    //
    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ARRAY_BUFFER, lev2_instance_3_VBO);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    glVertexAttribDivisor(2, 1); // Tell OpenGL this is an instanced vertex attribute.
//
    glBindVertexArray(0);
    
}



void little_cone_level_2_3_other_side(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    lev2_3_count_side = 0;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    lev2_little_cone_side_3[0].x = 0.2;
    lev2_little_cone_side_3[0].y = 0.6f;
    lev2_little_cone_side_3[0].z = 0.4f;
    

    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = .37f+ outer.z  + lev2_little_3_radius * cos(rad);
        outer.y =  0.58f + outer.y + lev2_little_3_radius * sin(rad);
        outer.x =  -0.1f + outer.x ;
        
        
        lev2_little_cone_side_3[idx++] = outer;
        lev2_3_count_side++;
    }
    
    
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
    while (count_cone < lev2_3_count_side) {
        idx = count_cone * 3;
        lev2_little_3_side_cone[idx+0] = lev2_little_cone_side_3[0];
        lev2_little_3_side_cone[idx+1] = lev2_little_cone_side_3[i];
        lev2_little_3_side_cone[idx+2] = lev2_little_cone_side_3[j];
        i++;
        j++;
        count_cone++;
    }
    
    little_cone_texture();
    lev2_make_instance_2();
    
    
    glGenVertexArrays(1, &lev2_little_3_side_VAO);
    glGenBuffers(1,&lev2_little_3_side_VBO);
    glBindVertexArray(lev2_little_3_side_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,lev2_little_3_side_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(lev2_little_3_side_cone) ,lev2_little_3_side_cone, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(3);  // texture coords
    glBindBuffer(GL_ARRAY_BUFFER, little_cone_texture_VBO);
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ARRAY_BUFFER,lev2_instance_3_VBO);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);

    glVertexAttribDivisor(2, 1); // Tell OpenGL this is an instanced vertex attribute.
    
    glBindVertexArray(0);
    
}


void deletion_lev2__3_little_buffer(){
    
    glDeleteBuffers(1,&lev2_little_3_VBO);
    glDeleteBuffers(1,&lev2_little_3_VAO);
    glDeleteBuffers(1,&lev2_little_3_side_VBO);
    glDeleteBuffers(1,&lev2_little_3_side_VAO);
    
    glDeleteBuffers(1,&lev2_instance_3_VBO);
}



