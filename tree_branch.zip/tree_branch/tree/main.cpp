
#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

// GL includes
#include "Shader.h"
//#include "SOIL.h"

#include <SOIL.h>

#include "branches.h"
#include "gl_positionVariables.h"

#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#define GLEW_STATIC

//bool keys[1024];
//bool firstMouse = true;
//GLfloat lastX = 400, lastY = 300;
//
//glm::vec3 cameraPos   = glm::vec3(0.0f, 0.0f,  3.0f);
//glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
//glm::vec3 cameraUp    = glm::vec3(0.0f, 1.0f,  0.0f);
//
//GLfloat yaw    = -90.0f;	// Yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right (due to how Eular angles work) so we initially rotate a bit to the left.
//GLfloat pitch  =  0.0f;
//
//void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
//{
//    
//    GLfloat cameraSpeed = 0.02f;
//    if(key == GLFW_KEY_W)
//        cameraPos += cameraSpeed * cameraFront;
//    if(key == GLFW_KEY_S)
//        cameraPos -= cameraSpeed * cameraFront;
//    if(key == GLFW_KEY_A)
//        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
//    if(key == GLFW_KEY_D)
//        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
//}
//void mouse_callback(GLFWwindow* window, double xpos, double ypos)
//{
//    if (firstMouse)
//    {
//        lastX = xpos;
//        lastY = ypos;
//        firstMouse = false;
//    }
//    
//    GLfloat xoffset = xpos - lastX;
//    GLfloat yoffset = lastY - ypos; // Reversed since y-coordinates go from bottom to left
//    lastX = xpos;
//    lastY = ypos;
//    
//    GLfloat sensitivity = 0.05;	// Change this value to your liking
//    xoffset *= sensitivity;
//    yoffset *= sensitivity;
//    
//    yaw   += xoffset;
//    pitch += yoffset;
//    
//    // Make sure that when pitch is out of bounds, screen doesn't get flipped
//    if (pitch > 89.0f)
//        pitch = 89.0f;
//    if (pitch < -89.0f)
//        pitch = -89.0f;
//    
//    glm::vec3 front;
//    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
//    front.y = sin(glm::radians(pitch));
//    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
//    cameraFront = glm::normalize(front);
//}
//



int main(int argc, char **argv)
{
    
    // Init GLFW
    glfwInit();
    
    glfwWindowHint (GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    // Set all the required options for GLFW
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);
    
    
    GLFWwindow* window = glfwCreateWindow(800, 600, "Hello World", NULL, NULL);
    glfwMakeContextCurrent(window);
    
    
    glfwSetKeyCallback(window, key_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glewExperimental = GL_TRUE;
    
    
    glewInit();
    
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    glViewport(0, 0, width, height);
    
    glEnable(GL_DEPTH_TEST);
    
    
    Shader shader("basic.vert", "basic.frag");
    
    upper_circle();
    UpperCircle_buffer();
    
    down_circle();
    DownCircle_buffer();
    
    cylinder();
    cylinder_buffer();
    
    // texture------------------------------------------
    // Load and create a texture
    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture); // All upcoming GL_TEXTURE_2D operations now have effect on this texture object
    // Set the texture wrapping parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// Set texture wrapping to GL_REPEAT (usually basic wrapping method)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // Set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // Load image, create texture and generate mipmaps
    int width_texture, height_texture;
    unsigned char* image = SOIL_load_image("/Users/Chiaoysbaby/desktop/tree/tree_bark.jpg", &width_texture, &height_texture, 0, SOIL_LOAD_RGB);
    
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width_texture, height_texture, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(image);
    glBindTexture(GL_TEXTURE_2D, 0); // Unbind texture when done, so we won't accidentily mess up our texture.
    // texture------------------------------------------
    
    
    
    while (!glfwWindowShouldClose(window))
    {
        
        glfwPollEvents();

        glColorMask (GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
        glDepthMask (GL_TRUE);
        glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
 
        
        do_movement();

        //        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture);
        

        setUp_gl_position(shader);
        
        shader.Use();
        
        glBindVertexArray(sphereVAO);
        //        glDrawArrays(GL_LINE_LOOP, 2, outerVertexCount);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(sphere_downVAO);
        //        glDrawArrays(GL_LINE_LOOP, 2, outerVertexCount);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(cylinderVAO);
        
        //GL_TRIANGLE_STRIP
        //        glDrawArrays(GL_LINE_LOOP, 2, outerVertexCount);
        //6*8;GL_TRIANGLE_STRIP
        //        glDrawArrays(GL_TRIANGLES, 0, 48);
        glDrawElements(GL_TRIANGLES, 60, GL_UNSIGNED_INT, (void*)0);
        
        glBindVertexArray(0);
        
        glfwSwapBuffers(window);
        
        
        
    }
    
    delete_buffers();
    glfwTerminate();
    return 0;
    
    
}
