
#define sides 11

int count = 0;
float radius = 0.05f;


void botton_circle(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 0;
    
    int outerVertexCount = vertexCount-1;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.x = outer.x  + radius * cos(rad);
        //        outer.y = outer.y + radius * sin(rad);
        
//        outer.y = outer.y + -1.0f;
        //        outer.z = outer.z + 0;
        outer.y = outer.z + radius * sin(rad);
        
        outer.z = outer.y + -1.0f;
        
        buffer[idx++] = outer;
        count++;
    }
}