
#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include "Shader.h"
#include "Model.h"

//#include "Camera.h"

#include <SOIL.h>

#include "branches.h"
//#include "gl_positionVariables.h"
#include "first_branch.h"
#include "second_branch.h"
#include "third_branch.h"
#include "little_branch.h"


#include <GLFW/glfw3.h>

//glm
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>



#include "leaf.h"

#define GLEW_STATIC

glm::vec3 cameraPos   = glm::vec3(0.0f, 0.0f,  3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp    = glm::vec3(0.0f, 1.0f,  0.0f);


GLfloat Time_radius = 5.0f;


const GLuint WIDTH = 800, HEIGHT = 600;


GLfloat yaw    = -90.0f;	// Yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right (due to how Eular angles work) so we initially rotate a bit to the left.
GLfloat pitch  =  0.0f;
GLfloat lastX  =  WIDTH  / 2.0;
GLfloat lastY  =  HEIGHT / 2.0;
GLfloat fov =  45.0f;
bool keys[1024];


// Deltatime
GLfloat deltaTime = 0.0f;	// Time between current frame and last frame
GLfloat lastFrame = 0.0f;  	// Time of last frame

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void Do_Movement();
void calculation_deltatime();

int main(int argc, char **argv)
{
    


    // Init GLFW
    glfwInit();
    
    glfwWindowHint (GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    // Set all the required options for GLFW
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);
    
    
    GLFWwindow* window = glfwCreateWindow(800, 600, "Hello World", NULL, NULL);
    glfwMakeContextCurrent(window);
    
    
    glfwSetKeyCallback(window, key_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glewExperimental = GL_TRUE;
    
    
    glewInit();
    
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    glViewport(0, 0, width, height);
    
    
       
    glEnable(GL_DEPTH_TEST);
    
    
    Shader shader("basic.vert", "basic.frag");
    Shader branch_shader("branch_instancing.vert", "branch_instancing.frag");
    Shader leaf_shader("leaf.vert","leaf.frag");
    
    
//   
    Model ourModel("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
//    TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
    
    upper_circle();
    UpperCircle_buffer();
    
    down_circle();
    DownCircle_buffer();
    
    cylinder();
    cylinder_buffer();
    
   
    make_cone_level_1_1();
    make_cone_level_1_2();
    make_cone_level_1_3();
    make_cone_level_1_4();
    make_cone_level_1_5();
  
    make_cone_level_2_1();
    make_cone_level_2_2();
    make_cone_level_2_3();
    make_cone_level_2_4();
    make_cone_level_2_5();

    make_cone_level_3_1();
    make_cone_level_3_2();
    make_cone_level_3_3();

    
   little_cone_level_1_1();
   little_cone_level_1_1_other_side();
    
    //little_cone_level_1_2();
    
    // texture------------------------------------------
    // Load and create a texture
    GLuint bark_texture;
    glGenTextures(1, &bark_texture);
    glBindTexture(GL_TEXTURE_2D, bark_texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // Set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // Load image, create texture and generate mipmaps
    int width_texture, height_texture;
    unsigned char* image = SOIL_load_image("/Users/Chiaoysbaby/desktop/tree/tree_bark.jpg", &width_texture, &height_texture, 0, SOIL_LOAD_RGB);
    
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width_texture, height_texture, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(image);
    glBindTexture(GL_TEXTURE_2D, 0);
    
    
    
    
    while (!glfwWindowShouldClose(window))
    {
        
        glfwPollEvents();

        glColorMask (GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
        glDepthMask (GL_TRUE);
        glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
 
        
        Do_Movement();
        
        glActiveTexture (GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, bark_texture);
        
        
        
        GLfloat camX = sin(glfwGetTime())*0.5 * Time_radius;
        GLfloat camZ = cos(glfwGetTime())*0.5 * Time_radius;

        
     
        shader.Use();
        glm::mat4 projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(shader.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(projection));
        
        glm::mat4 view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        
        //glm::mat4 view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));

        glUniformMatrix4fv(glGetUniformLocation(shader.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(view));
        
        // Draw the loaded model
        glm::mat4 model;
       // model = glm::translate(model, glm::vec3(0.0f, -5.0f, 0.0f));
       // model = glm::scale(model, glm::vec3(4.0f, 4.0f, 4.0f));
       glUniformMatrix4fv(glGetUniformLocation(shader.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(model));
        
        
        branch_shader.Use();//-----------------------
        glm::mat4 branch_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(branch_shader.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(branch_projection));
        
    glm::mat4 branch_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        
      //  glm::mat4 branch_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        
        glUniformMatrix4fv(glGetUniformLocation(branch_shader.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(branch_view));
        
        glm::mat4 branch_model;
        glUniformMatrix4fv(glGetUniformLocation(branch_shader.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(branch_model));
        
        
        leaf_shader.Use();//---------------------
        glm::mat4 leaf_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(leaf_shader.Program, "projection"), 1, GL_FALSE, glm::value_ptr(leaf_projection));
        
        glm::mat4 leaf_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        
       // glm::mat4 leaf_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        
        glUniformMatrix4fv(glGetUniformLocation(leaf_shader.Program, "view"), 1, GL_FALSE, glm::value_ptr(leaf_view));
        
        // Draw the loaded model
        glm::mat4 leaf_model;
       // leaf_model = glm::translate(leaf_model, glm::vec3(.3f, .51f, 0.0f));
        
        leaf_model = glm::translate(leaf_model, glm::vec3(0.0f, 0.0f, 0.0f));
       // leaf_model = glm::translate(leaf_model, glm::vec3(1, 3.0f, -1.0f));//
        
       // Translate it down a bit so it's at the center of the scene
       // leaf_model = glm::scale(leaf_model, glm::vec3(0.02f, 0.02f, 0.02f));
        //leaf_model = glm::scale(leaf_model, glm::vec3(0.0005f, 0.01f, 0.005f));
       
        
         leaf_model = glm::scale(leaf_model, glm::vec3(0.005f, 0.01f, 0.009f));
        glUniformMatrix4fv(glGetUniformLocation(leaf_shader.Program, "model"), 1, GL_FALSE, glm::value_ptr(leaf_model));
        
        
        
        shader.Use();

        glBindVertexArray(sphereVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(sphere_downVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(cylinderVAO);
        glDrawElements(GL_TRIANGLES, 60, GL_UNSIGNED_INT, (void*)0);
        glBindVertexArray(0);

  

        glBindVertexArray(botton_1_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);

        glBindVertexArray(botton_2_VAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 27);
        glBindVertexArray(0);
//
        glBindVertexArray(botton_3_VAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 27);
        glBindVertexArray(0);
//
        glBindVertexArray(botton_4_VAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 27);
        glBindVertexArray(0);
        
        glBindVertexArray(botton_5_VAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 27);
        glBindVertexArray(0);

//        //------- level 2
      
        glBindVertexArray(medium_1_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
        
        glBindVertexArray(medium_2_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
        
        glBindVertexArray(medium_3_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
        
        glBindVertexArray(medium_4_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
        
        glBindVertexArray(medium_5_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
        
 
        glBindVertexArray(top_1_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);

        glBindVertexArray(top_2_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);

        glBindVertexArray(top_3_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
        
  
       // glActiveTexture (GL_TEXTURE1);
       // glBindTexture(GL_TEXTURE_2D, bark_texture);

        branch_shader.Use();

        
        glBindVertexArray(little_1_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 4);
        glBindVertexArray(0);

        glBindVertexArray(little_1_side_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 4);
        glBindVertexArray(0);
        
        glBindVertexArray(little_2_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 4);
        glBindVertexArray(0);



        leaf_shader.Use();
        leaf_positions(ourModel);
      //  glActiveTexture (GL_TEXTURE1);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
       // ourModel.Draw(leaf_shader);
  
        
        
        glBindTexture(GL_TEXTURE_2D, ourModel.textures_loaded[0].id);
     
        for(GLuint i = 0; i < ourModel.meshes.size(); i++)
        {
            
            glBindVertexArray(ourModel.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 10000);
            glBindVertexArray(0);
        }
  
        
        
        
        
        glfwSwapBuffers(window);
        
        
        
    }
    
    delete_buffers();
    deletion_branches_buffer();
    deletion_medium_buffer();
  //  deletion_top_medium_buffer();
    deletion_little_buffer();
    
    glfwTerminate();
    return 0;
    
    
}


#pragma region "User input"



void calculation_deltatime(){
    
    GLfloat currentFrame = glfwGetTime();
    deltaTime = currentFrame - lastFrame;
    lastFrame = currentFrame;
    
}





void Do_Movement()
{
    
    calculation_deltatime();
    
    // Camera controls
    GLfloat cameraSpeed = 5.0f * deltaTime;
    if (keys[GLFW_KEY_W])
        cameraPos += cameraSpeed * cameraFront;
    if (keys[GLFW_KEY_S])
        cameraPos -= cameraSpeed * cameraFront;
    if (keys[GLFW_KEY_A])
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (keys[GLFW_KEY_D])
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
}


void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
    if (key >= 0 && key < 1024)
    {
        if (action == GLFW_PRESS)
            keys[key] = true;
        else if (action == GLFW_RELEASE)
            keys[key] = false;
    }
}


void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    if (fov >= 1.0f && fov <= 45.0f)
        fov -= yoffset;
    if (fov <= 1.0f)
        fov = 1.0f;
    if (fov >= 45.0f)
        fov = 45.0f;
}

bool firstMouse = true;
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }
    
    GLfloat xoffset = xpos - lastX;
    GLfloat yoffset = lastY - ypos; // Reversed since y-coordinates go from bottom to left
    lastX = xpos;
    lastY = ypos;
    
    GLfloat sensitivity = 0.05;	// Change this value to your liking
    xoffset *= sensitivity;
    yoffset *= sensitivity;
    
    yaw   += xoffset;
    pitch += yoffset;
    
    // Make sure that when pitch is out of bounds, screen doesn't get flipped
    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;
    
    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}



#pragma endregion
