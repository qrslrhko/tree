#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//#include "first_branch.h"

#define sides 11
#define radius 0.05

glm::vec3 level_2_1_cone[500];
glm::vec3 level_2_2_cone[500];
glm::vec3 level_2_3_cone[500];
glm::vec3 level_2_4_cone[500];
glm::vec3 level_2_5_cone[500];

glm::vec3 medium_cone_1[500];
glm::vec3 medium_cone_2[500];
glm::vec3 medium_cone_3[500];
glm::vec3 medium_cone_4[500];
glm::vec3 medium_cone_5[500];

GLuint medium_1_VBO,medium_1_VAO;
GLuint medium_2_VBO,medium_2_VAO;
GLuint medium_3_VBO,medium_3_VAO;
GLuint medium_4_VBO,medium_4_VAO;
GLuint medium_5_VBO,medium_5_VAO;


//glm::vec3 translation[2];
//GLuint instance_VBO;

glm::vec3 medium_texture_cone_buffer[500];
GLuint medium_cone_texture_VBO;



void medium_blind_cone_texture(){
    // texture_buffer = {1.0f, 1.0f,  1.0f, 0.0f,  0.0f, 0.0f,  0.0f, 1.0f};
    
    int in_count = 0;
    int index = 0;
    //  printf("@@@@: count_side    %d \n ", count_side);
    while (in_count < count_side) {
        // printf("!!!!!!\n ");
        index = in_count * 3;
        medium_texture_cone_buffer[index +0 ].x =1.0f;
        medium_texture_cone_buffer[index +0 ].y =0.0f;
        
        medium_texture_cone_buffer[index + 1].x =0.5f;
        medium_texture_cone_buffer[index + 1].y =1.0f;
        
        medium_texture_cone_buffer[index + 2].x =0.0f;
        medium_texture_cone_buffer[index + 2].y =0.0f;
        //
        //        texture_cone_buffer[index + 3].x =0.0f;
        //        texture_cone_buffer[index + 3].y =1.0f;
        
        //  printf(">>>>index: %d \n ", index);
        //        index = in_count * 3;
        in_count++;
        
    }
    
    
    // texture array buffer
    glGenBuffers(1,&medium_cone_texture_VBO);
    glBindBuffer(GL_ARRAY_BUFFER,medium_cone_texture_VBO);
    //  glBufferData(GL_ARRAY_BUFFER,sizeof(glm::vec2) * 8 ,texture_buffer, GL_STATIC_DRAW);
    glBufferData(GL_ARRAY_BUFFER,sizeof(medium_texture_cone_buffer),medium_texture_cone_buffer, GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    
}



void make_cone_level_2_1(){
    
    
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    level_2_1_cone[0].x = 0.8;
    level_2_1_cone[0].y = 0.7;
    level_2_1_cone[0].z = 0;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = .01f + outer.z  + radius * cos(rad);
        //        outer.y = outer.y + radius * sin(rad);
        
        //        outer.y = outer.y + -1.0f;
        //        outer.z = outer.z + 0;
        outer.y = 0.4f + outer.y + radius * sin(rad);
        
        outer.x = outer.x ;
        
        level_2_1_cone[idx++] = outer;
        count_side++;
    }
    
    //    level_1_1_cone[idx] = level_1_1_cone[1];
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
    
    while (count_cone < count_side) {
        idx = count_cone * 3;
        medium_cone_1[idx+0] = level_2_1_cone[0];
        medium_cone_1[idx+1] = level_2_1_cone[i];
        medium_cone_1[idx+2] = level_2_1_cone[j];
        
        // printf("~~~ idx: %d \n",idx);
        //  printf("i: %d , j: %d \n", i,j);
        i++;
        j++;
        count_cone++;
    }
    
    
    
    
    // printf("idx: %d  \n ", idx);
    medium_blind_cone_texture();
    
    glGenVertexArrays(1, &medium_1_VAO);
    glGenBuffers(1,&medium_1_VBO);
    glBindVertexArray(medium_1_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,medium_1_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(medium_cone_1) ,medium_cone_1, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(7);  // texture coords
    // Map index 1 to the texture coords buffer
    glBindBuffer(GL_ARRAY_BUFFER,  medium_cone_texture_VBO);
    //    glVertexAttribPointer( 3, 2, GL_FLOAT, GL_FALSE, 0,(GLubyte *)NULL );
    
    glVertexAttribPointer(7, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    
}


void make_cone_level_2_2(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    level_2_2_cone[0].x = -0.01;
    level_2_2_cone[0].y = 0.7;
    level_2_2_cone[0].z = -0.5;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = .01f + outer.z  + radius * cos(rad);
        //        outer.y = outer.y + radius * sin(rad);
        
        //        outer.y = outer.y + -1.0f;
        //        outer.z = outer.z + 0;
        outer.y = 0.4f + outer.y + radius * sin(rad);
        
        outer.x = outer.x ;
        
        level_2_2_cone[idx++] = outer;
        count_side++;
    }
    
    //    level_1_2_cone[idx] = level_1_2_cone[1];
    // printf("idx: %d  \n ", idx);
    
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
    
    while (count_cone < count_side) {
        idx = count_cone * 3;
        medium_cone_2[idx+0] = level_2_2_cone[0];
        medium_cone_2[idx+1] = level_2_2_cone[i];
        medium_cone_2[idx+2] = level_2_2_cone[j];
        
        // printf("~~~ idx: %d \n",idx);
        //  printf("i: %d , j: %d \n", i,j);
        i++;
        j++;
        count_cone++;
    }
    
    
    glGenVertexArrays(1, &medium_2_VAO);
    glGenBuffers(1,&medium_2_VBO);
    glBindVertexArray(medium_2_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,medium_2_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(medium_cone_2) ,medium_cone_2, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(8);  // texture coords
    // Map index 1 to the texture coords buffer
    glBindBuffer(GL_ARRAY_BUFFER, medium_cone_texture_VBO);
    //    glVertexAttribPointer( 3, 2, GL_FLOAT, GL_FALSE, 0,(GLubyte *)NULL );
    
    glVertexAttribPointer(8, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    
}




void make_cone_level_2_3(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    level_2_3_cone[0].x = -0.4;
    level_2_3_cone[0].y = 0.7;
    level_2_3_cone[0].z = -0.3;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = 0.01f + outer.z  - radius * cos(rad);
        //        outer.y = outer.y + radius * sin(rad);
        
        //        outer.y = outer.y + -1.0f;
        //        outer.z = outer.z + 0;
        outer.y = 0.4f + outer.y - radius * sin(rad);
        
        outer.x = 0.01f + outer.x ;
        
        level_2_3_cone[idx++] = outer;
        count_side++;
    }
    
    //    level_1_2_cone[idx] = level_1_2_cone[1];
    // printf("idx: %d  \n ", idx);
    
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
    
    while (count_cone < count_side) {
        idx = count_cone * 3;
        medium_cone_3[idx+0] = level_2_3_cone[0];
        medium_cone_3[idx+1] = level_2_3_cone[i];
        medium_cone_3[idx+2] = level_2_3_cone[j];
        
        printf(">>>  idx: %d \n",idx);
        printf(">>> i: %d , j: %d \n", i,j);
        i++;
        j++;
        count_cone++;
    }
    
    
    glGenVertexArrays(1, &medium_3_VAO);
    glGenBuffers(1,&medium_3_VBO);
    glBindVertexArray(medium_3_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,medium_3_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(medium_cone_3) ,medium_cone_3, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(9);  // texture coords
    // Map index 1 to the texture coords buffer
    glBindBuffer(GL_ARRAY_BUFFER, medium_cone_texture_VBO);
    //    glVertexAttribPointer( 3, 2, GL_FLOAT, GL_FALSE, 0,(GLubyte *)NULL );
    
    glVertexAttribPointer(9, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    
}


void make_cone_level_2_4(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    //    level_1_4_cone[0].x = 0.2;
    //    level_1_4_cone[0].y = 0.3;
    //    level_1_4_cone[0].z = 1.4;
    
    level_2_4_cone[0].x = -0.2;
    level_2_4_cone[0].y = 0.7;
    level_2_4_cone[0].z = 0.6;
    
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.y = 0.4f + outer.y  - radius * cos(rad);
        //        outer.y = outer.y + radius * sin(rad);
        
        //        outer.y = outer.y + -1.0f;
        //        outer.z = outer.z + 0;
        outer.z = 0.01f + outer.z - radius * sin(rad);
        
        outer.x = 0 + outer.x ;
        
        level_2_4_cone[idx++] = outer;
        count_side++;
    }
    
    //    level_1_2_cone[idx] = level_1_2_cone[1];
    // printf("idx: %d  \n ", idx);
    
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
    
    while (count_cone < count_side) {
        idx = count_cone * 3;
        medium_cone_4[idx+0] = level_2_4_cone[0];
        medium_cone_4[idx+1] = level_2_4_cone[i];
        medium_cone_4[idx+2] = level_2_4_cone[j];
        
        printf(">>>  idx: %d \n",idx);
        printf(">>> i: %d , j: %d \n", i,j);
        i++;
        j++;
        count_cone++;
    }
    
    
    glGenVertexArrays(1, &medium_4_VAO);
    glGenBuffers(1,&medium_4_VBO);
    glBindVertexArray(medium_4_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,medium_4_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(medium_cone_4) ,medium_cone_4, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(10);  // texture coords
    // Map index 1 to the texture coords buffer
    glBindBuffer(GL_ARRAY_BUFFER, medium_cone_texture_VBO);
    //    glVertexAttribPointer( 3, 2, GL_FLOAT, GL_FALSE, 0,(GLubyte *)NULL );
    
    glVertexAttribPointer(10, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    
}


void make_cone_level_2_5(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    //    level_1_4_cone[0].x = 0.2;
    //    level_1_4_cone[0].y = 0.3;
    //    level_1_4_cone[0].z = 1.4;
    
    level_2_5_cone[0].x = 0.6;
    level_2_5_cone[0].y = 0.8;
    level_2_5_cone[0].z = 0.74;
    
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = -0.04f + outer.z  - radius * cos(rad);
        //        outer.y = outer.y + radius * sin(rad);
        
        //        outer.y = outer.y + -1.0f;
        //        outer.z = outer.z + 0;
        outer.y = 0.4f + outer.y + radius * sin(rad);
        
        outer.x = 0 + outer.x ;
        
        level_2_5_cone[idx++] = outer;
        count_side++;
    }
    
    //    level_1_2_cone[idx] = level_1_2_cone[1];
    // printf("idx: %d  \n ", idx);
    
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
    
    while (count_cone < count_side) {
        idx = count_cone * 3;
        medium_cone_5[idx+0] = level_2_5_cone[0];
        medium_cone_5[idx+1] = level_2_5_cone[i];
        medium_cone_5[idx+2] = level_2_5_cone[j];
        
        printf(">>>  idx: %d \n",idx);
        printf(">>> i: %d , j: %d \n", i,j);
        i++;
        j++;
        count_cone++;
    }
    
    
    glGenVertexArrays(1, &medium_5_VAO);
    glGenBuffers(1,&medium_5_VBO);
    glBindVertexArray(medium_5_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,medium_5_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(medium_cone_5) ,medium_cone_5, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(11);  // texture coords
    // Map index 1 to the texture coords buffer
    glBindBuffer(GL_ARRAY_BUFFER, medium_cone_texture_VBO);
    //    glVertexAttribPointer( 3, 2, GL_FLOAT, GL_FALSE, 0,(GLubyte *)NULL );
    
    glVertexAttribPointer(11, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    
}




void deletion_medium_buffer(){
    
    glDeleteBuffers(1,&medium_1_VAO);
    glDeleteBuffers(1,&medium_1_VBO);
    glDeleteBuffers(1,&medium_2_VAO);
    glDeleteBuffers(1,&medium_2_VBO);
    glDeleteBuffers(1,&medium_3_VAO);
    glDeleteBuffers(1,&medium_3_VBO);
    glDeleteBuffers(1,&medium_4_VAO);
    glDeleteBuffers(1,&medium_4_VBO);
    glDeleteBuffers(1,&medium_5_VAO);
    glDeleteBuffers(1,&medium_5_VBO);
    glDeleteBuffers(1,& medium_cone_texture_VBO);
    //    glDeleteBuffers(1,&instance_VBO);
}



