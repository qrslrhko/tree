#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>


#define sides 11
#define little_3_radius 0.02


glm::vec3 little_1_3_cone[500];
glm::vec3 little_1_3_side_cone[500];

glm::vec3 little_cone_3[500];
glm::vec3 little_cone_side_3[500];

GLuint little_3_VBO,little_3_VAO;
GLuint little_3_side_VBO,little_3_side_VAO;

glm::vec3 translations_3[100];
GLuint instance_3_VBO;


int little_3_count_side = 0;


void make_instance_3(){
    translations_3[0].x = -0.07;
    translations_3[0].y = 0.045;
    translations_3[0].z = 0.2;
//    
    translations_3[1].x = -0.11;
    translations_3[1].y = 0.07;
    translations_3[1].z = 0.5;
    //
    //    translations_3[2].x = -0.4;
    //    translations_3[2].y = -0.04;
    //    translations_3[2].z = 0.05;
    //
    //    translations[3].x = 1.33;
    //    translations[3].y = 0.12;
    //    translations[3].z = 1.02;
    
    
    glGenBuffers(1, &instance_3_VBO);
    glBindBuffer(GL_ARRAY_BUFFER, instance_3_VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(translations_3), translations_3, GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, 0);

}


void little_cone_level_1_3(){

    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    little_3_count_side = 0;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    little_1_3_cone[0].x = -0.3;
    little_1_3_cone[0].y = 0.1;
    little_1_3_cone[0].z = 0.2;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = 0.28f + outer.z  + little_3_radius * cos(rad);
        outer.y =  0.04f + outer.y + little_3_radius * sin(rad);
        outer.x = -0.01f + outer.x ;
        
        little_1_3_cone[idx++] = outer;
        little_3_count_side++;
    }
    //
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
    printf("idx+2: %d ",idx + 2);
    while (count_cone < little_3_count_side) {
        idx = count_cone * 3;
        little_cone_3[idx+0] = little_1_3_cone[0];
        little_cone_3[idx+1] = little_1_3_cone[i];
        little_cone_3[idx+2] = little_1_3_cone[j];
        i++;
        j++;
        count_cone++;
    }
    
    
    little_cone_texture();
    make_instance_3();
    
    
    glGenVertexArrays(1, &little_3_VAO);
    glGenBuffers(1,&little_3_VBO);
    glBindVertexArray(little_3_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,little_3_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(little_cone_3) ,little_cone_3, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(1);  // texture coords
    glBindBuffer(GL_ARRAY_BUFFER, little_cone_texture_VBO);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
//  
    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ARRAY_BUFFER, instance_3_VBO);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    
    glVertexAttribDivisor(2, 1);
    // Tell OpenGL this is an instanced vertex attribute.
    //
    glBindVertexArray(0);
    

}




void little_cone_level_1_3_other_side(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    little_3_count_side = 0;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    little_1_3_side_cone[0].x = 0.3;
    little_1_3_side_cone[0].y = 0.1;
    little_1_3_side_cone[0].z = 0.2;
   

    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = 0.28f + outer.z  + little_3_radius * cos(rad);
        outer.y =  0.04f + outer.y + little_3_radius * sin(rad);
        outer.x = -0.01f + outer.x ;
        
        
        
        little_1_3_side_cone[idx++] = outer;
        little_3_count_side++;
    }
    
    
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
   // printf("little: %d \n ", little_count_side);
    while (count_cone < little_2_count_side) {
        idx = count_cone * 3;
        little_cone_side_3[idx+0] = little_1_3_side_cone[0];
        little_cone_side_3[idx+1] = little_1_3_side_cone[i];
        little_cone_side_3[idx+2] = little_1_3_side_cone[j];
        printf("idx: %d \n ",idx);
        i++;
        j++;
        count_cone++;
    }
    
    little_cone_texture();
    make_instance_3();
    
    
    glGenVertexArrays(1, &little_3_side_VAO);
    glGenBuffers(1,&little_3_side_VBO);
    glBindVertexArray(little_3_side_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,little_3_side_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(little_cone_side_3) ,little_cone_side_3, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(3);  // texture coords
    glBindBuffer(GL_ARRAY_BUFFER, little_cone_texture_VBO);
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ARRAY_BUFFER,instance_3_VBO);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    //  glBindBuffer(GL_ARRAY_BUFFER, 0);
    
    
    glVertexAttribDivisor(2, 1); // Tell OpenGL this is an instanced vertex attribute.
    
    glBindVertexArray(0);
    
}




void deletion_3_little_buffer(){
    
    glDeleteBuffers(1,&little_3_VBO);
    glDeleteBuffers(1,&little_3_VAO);
    glDeleteBuffers(1,&little_3_side_VBO);
    glDeleteBuffers(1,&little_3_side_VAO);
    
    glDeleteBuffers(1,&instance_3_VBO);
}





