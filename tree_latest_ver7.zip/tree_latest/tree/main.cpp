
#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include "Shader.h"
#include "Model.h"

#include <SOIL.h>

#include "branches.h"
//#include "gl_positionVariables.h"
#include "first_branch.h"
#include "second_branch.h"
#include "third_branch.h"
#include "little_branch.h"
#include "little_branch_2_.h"

#include "little_branch_3_.h"

#include "little_branch_4_.h"
#include "little_branch_5_.h"


#include "level2_little_branch.h"
#include "level2_little_1_branch.h"
#include "level2_little_2_branch.h"
#include "level2_little_3_branch.h"
#include "level2_little_4_branch.h"

#include <GLFW/glfw3.h>

//glm
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>



#include "leaf.h"

#include "leaf_position.h"

#define GLEW_STATIC

glm::vec3 cameraPos   = glm::vec3(0.0f, 0.0f,  3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp    = glm::vec3(0.0f, 1.0f,  0.0f);


GLfloat Time_radius = 5.0f;


const GLuint WIDTH = 800, HEIGHT = 600;


GLfloat yaw    = -90.0f;
GLfloat pitch  =  0.0f;
GLfloat lastX  =  WIDTH  / 2.0;
GLfloat lastY  =  HEIGHT / 2.0;
GLfloat fov =  45.0f;
bool keys[1024];


// Deltatime
GLfloat deltaTime = 0.0f;	// Time between current frame and last frame
GLfloat lastFrame = 0.0f;  	// Time of last frame


bool level_3_ON = false, level_3_OFF = true;
bool level_2_ON = false;



void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void Do_Movement();
void calculation_deltatime();
void control_rotation();


int main(int argc, char **argv)
{
    


    // Init GLFW
    glfwInit();
    
    glfwWindowHint (GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);
    
    
    GLFWwindow* window = glfwCreateWindow(800, 600, "Hello World", NULL, NULL);
    glfwMakeContextCurrent(window);
    
    
    glfwSetKeyCallback(window, key_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glewExperimental = GL_TRUE;
    
    
    glewInit();
    
    int width, height;
    glfwGetFramebufferSize(window, &width, &height);
    glViewport(0, 0, width, height);
    
    
       
    glEnable(GL_DEPTH_TEST);
    
    
    Shader shader("basic.vert", "basic.frag");
    Shader branch_shader("branch_instancing.vert", "branch_instancing.frag");
    
    Shader branch_shader_1("branch_instancing.vert", "branch_instancing.frag");
    Shader branch_shader_2("branch_instancing.vert", "branch_instancing.frag");
    Shader branch_shader_3("branch_instancing.vert","branch_instancing.frag");
    Shader branch_shader_4("branch_instancing.vert","branch_instancing.frag");
    
    
    
    
    Shader leve2_branch_1("branch_ins_lev2_1.vert","branch_ins_lev2_1.frag");
    Shader leve2_branch_2("branch_ins_lev2_1.vert","branch_ins_lev2_1.frag");
    Shader leve2_branch_3("branch_ins_lev2_1.vert","branch_ins_lev2_1.frag");
    Shader leve2_branch_4("branch_ins_lev2_1.vert","branch_ins_lev2_1.frag");
    Shader leve2_branch_5("branch_ins_lev2_1.vert","branch_ins_lev2_1.frag");

   // Shader leaf_shader("leaf.vert","leaf.frag");
    
    
    Shader leaf_shader_top("leaf.vert","leaf.frag");
    
    Shader leaf_shader("leaf.vert","leaf.frag");
    Shader leaf_shader_1("leaf.vert","leaf.frag");
    Shader leaf_shader_2("leaf.vert","leaf.frag");
    Shader leaf_shader_2_1("leaf.vert","leaf.frag");
    Shader leaf_shader_3("leaf.vert","leaf.frag");
    Shader leaf_shader_3_1("leaf.vert","leaf.frag");
    Shader leaf_shader_4("leaf.vert","leaf.frag");
    Shader leaf_shader_4_1("leaf.vert","leaf.frag");
    Shader leaf_shader_5("leaf.vert","leaf.frag");
    Shader leaf_shader_5_1("leaf.vert","leaf.frag");
    
    Shader leaf_shader_down1_1("leaf.vert","leaf.frag");
    Shader leaf_shader_down1_2("leaf.vert","leaf.frag");
    Shader leaf_shader_down1_3("leaf.vert","leaf.frag");
    Shader leaf_shader_down1_4("leaf.vert","leaf.frag");
    Shader leaf_shader_down1_5("leaf.vert","leaf.frag");
    
    
//
    Model ourModel_top("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_1("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_2("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_2_1("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_3("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_3_1("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_4("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_4_1("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_5("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_5_1("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    
    
    Model ourModel_down1_1("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_down1_2("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_down1_3("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_down1_4("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    Model ourModel_down1_5("/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj/paddle.obj");
    
    
    
//    TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
    
    upper_circle();
    UpperCircle_buffer();
    
    down_circle();
    DownCircle_buffer();
    
    cylinder();
    cylinder_buffer();
    
   
    make_cone_level_1_1();
    make_cone_level_1_2();
    make_cone_level_1_3();
    make_cone_level_1_4();
    make_cone_level_1_5();
  
    make_cone_level_2_1();
    make_cone_level_2_2();
    make_cone_level_2_3();
    make_cone_level_2_4();
    make_cone_level_2_5();

    make_cone_level_3_1();
    make_cone_level_3_2();
    make_cone_level_3_3();

   
    
    little_cone_level_1_1();
    little_cone_level_1_1_other_side();
    
  
    little_cone_level_1_2();
    little_cone_level_1_2_other_side();
    
    
    little_cone_level_1_3();
    little_cone_level_1_3_other_side();
   
    
    little_cone_level_1_4();
    little_cone_level_1_4_other_side();

    little_cone_level_1_5();
    little_cone_level_1_5_other_side();
    
    
    little_cone_level_2_1();
    little_cone_level_2_1_other_side();
    
    little_cone_level_2_2();
    little_cone_level_2_2_other_side();
    
    little_cone_level_2_3();
    little_cone_level_2_3_other_side();
    
    
    little_cone_level_2_4();
    little_cone_level_2_4_other_side();
    
    
    little_cone_level_2_5();
    little_cone_level_2_5_other_side();
    
    // texture------------------------------------------
    // Load and create a texture
    GLuint bark_texture;
    glGenTextures(1, &bark_texture);
    glBindTexture(GL_TEXTURE_2D, bark_texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // Set texture filtering parameters
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // Load image, create texture and generate mipmaps
    int width_texture, height_texture;
    unsigned char* image = SOIL_load_image("/Users/Chiaoysbaby/desktop/tree/tree_bark.jpg", &width_texture, &height_texture, 0, SOIL_LOAD_RGB);
    
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width_texture, height_texture, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    glGenerateMipmap(GL_TEXTURE_2D);
    SOIL_free_image_data(image);
    glBindTexture(GL_TEXTURE_2D, 0);
    //--------------------------------------------------------------------
    
    
    
    while (!glfwWindowShouldClose(window))
    {
        
        glfwPollEvents();

        glColorMask (GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
        glDepthMask (GL_TRUE);
        glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
 
        
        Do_Movement();
        control_rotation();
        
        
        glActiveTexture (GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, bark_texture);
        
        
        
        GLfloat camX = sin(glfwGetTime())*0.5 * Time_radius;
        GLfloat camZ = cos(glfwGetTime())*0.5 * Time_radius;

        
     
        shader.Use();
        glm::mat4 projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(shader.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(projection));

        glm::mat4 view;
        if(level_3_ON == true){
            
            view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        }else{
            view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        }
        
        glUniformMatrix4fv(glGetUniformLocation(shader.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(view));
        
        // Draw the loaded model
        glm::mat4 model;
       // model = glm::translate(model, glm::vec3(0.0f, -5.0f, 0.0f));
       // model = glm::scale(model, glm::vec3(4.0f, 4.0f, 4.0f));
       glUniformMatrix4fv(glGetUniformLocation(shader.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(model));
        
        
        branch_shader.Use();//-----------------------
        glm::mat4 branch_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(branch_shader.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(branch_projection));
        
         glm::mat4 branch_view;
        if(level_3_ON == true){
            branch_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        }else{
            branch_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        }
        
        glUniformMatrix4fv(glGetUniformLocation(branch_shader.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(branch_view));
        
        glm::mat4 branch_model;
        glUniformMatrix4fv(glGetUniformLocation(branch_shader.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(branch_model));
        
        
        //down branch _1 ------------------------
        
        branch_shader_1.Use();//-----------------------
        glm::mat4 branch_1_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(branch_shader_1.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(branch_1_projection));
           glm::mat4 branch_1_view;
        if(level_3_ON == true){
            
            branch_1_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        }else{
            branch_1_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        }

        
        glUniformMatrix4fv(glGetUniformLocation(branch_shader_1.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(branch_1_view));
        
        glm::mat4 branch_1_model;
        glUniformMatrix4fv(glGetUniformLocation(branch_shader_1.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(branch_1_model));

        
        //down branch _2 ------------------------
        
        branch_shader_2.Use();//-----------------------
        glm::mat4 branch_2_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(branch_shader_2.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(branch_2_projection));
        
          glm::mat4 branch_2_view;
        if(level_3_ON == true){

            branch_2_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        }else{
            branch_2_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        }
        
        glUniformMatrix4fv(glGetUniformLocation(branch_shader_2.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(branch_2_view));
        
        glm::mat4 branch_2_model;
        glUniformMatrix4fv(glGetUniformLocation(branch_shader_2.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(branch_2_model));
        

        
        
        //down branch _3 ------------------------
        
        branch_shader_3.Use();//-----------------------
        glm::mat4 branch_3_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(branch_shader_3.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(branch_3_projection));
    
        glm::mat4 branch_3_view;
        if(level_3_ON == true){
            
            branch_3_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        }else{
            branch_3_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        }
        
        glUniformMatrix4fv(glGetUniformLocation(branch_shader_3.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(branch_3_view));
        
        glm::mat4 branch_3_model;
        glUniformMatrix4fv(glGetUniformLocation(branch_shader_3.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(branch_3_model));
        

        
        //down branch _4 ------------------------
        
        branch_shader_4.Use();//-----------------------
        glm::mat4 branch_4_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(branch_shader_4.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(branch_4_projection));
        
        glm::mat4 branch_4_view;
        if(level_3_ON == true){

            branch_4_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        }else{
            branch_4_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        }

        glUniformMatrix4fv(glGetUniformLocation(branch_shader_4.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(branch_4_view));
        
        glm::mat4 branch_4_model;
        glUniformMatrix4fv(glGetUniformLocation(branch_shader_4.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(branch_4_model));
        

        
        
        //level 2 branch _1 ------------------------
        
        leve2_branch_1.Use();//-----------------------
        glm::mat4 lev2_branch_1_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_1.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_1_projection));
        
        glm::mat4 lev2_branch_1_view;
        if(level_3_ON == true){
            
            lev2_branch_1_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        }else{
            lev2_branch_1_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        }
        
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_1.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_1_view));
        
        glm::mat4 lev2_branch_1_model;
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_1.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_1_model));
        
        
        
        
        //level 2 branch _2 ------------------------
        
        leve2_branch_2.Use();//-----------------------
        glm::mat4 lev2_branch_2_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_2.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_2_projection));
        
        glm::mat4 lev2_branch_2_view;
        if(level_3_ON == true){
            
            lev2_branch_2_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        }else{
            lev2_branch_2_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        }
        
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_2.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_2_view));
        
        glm::mat4 lev2_branch_2_model;
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_2.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_2_model));
        

        
        
        //level 2 branch _3 ------------------------
        
        leve2_branch_3.Use();//-----------------------
        glm::mat4 lev2_branch_3_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_3.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_3_projection));
        
        
        glm::mat4 lev2_branch_3_view;
        if(level_3_ON == true){
            
            lev2_branch_3_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        }else{
            lev2_branch_3_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        }
        
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_3.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_3_view));
        
        glm::mat4 lev2_branch_3_model;
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_3.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_3_model));
        

        
        
        //level 2 branch _4 ------------------------
        
        leve2_branch_4.Use();//-----------------------
        glm::mat4 lev2_branch_4_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_4.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_4_projection));
        
        
        glm::mat4 lev2_branch_4_view;
        if(level_3_ON == true){
            
            lev2_branch_4_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        }else{
            lev2_branch_4_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        }
   
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_4.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_4_view));
        
        glm::mat4 lev2_branch_4_model;
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_4.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_4_model));
        

        
        
        //level 2 branch _5 ------------------------
        
        leve2_branch_5.Use();//-----------------------
        glm::mat4 lev2_branch_5_projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_5.Program, "projection_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_5_projection));
        
        
        glm::mat4 lev2_branch_5_view;
        if(level_3_ON == true){
            
           lev2_branch_5_view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
        }else{
            lev2_branch_5_view =  glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        }

        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_5.Program, "view_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_5_view));
        
        glm::mat4 lev2_branch_5_model;
        glUniformMatrix4fv(glGetUniformLocation(leve2_branch_5.Program, "model_matrix"), 1, GL_FALSE, glm::value_ptr(lev2_branch_5_model));
        
        
        
        leaf_shader.Use();//---------------------
        glm::vec3 TRANSLATION;
        TRANSLATION.x = 0.1f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.1f;
        
        setUp_leaf_position(leaf_shader,ourModel,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );

        
        leaf_shader_1.Use(); //------------------
        TRANSLATION.x = -0.1f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.1f;
        
        setUp_leaf_position(leaf_shader_1,ourModel_1,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        
        
        leaf_shader_2.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_2,ourModel_2,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        
        
        leaf_shader_2_1.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_2_1,ourModel_2_1,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        
        
        leaf_shader_3.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_3,ourModel_3,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        
        
        leaf_shader_3_1.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_3_1,ourModel_3_1,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        

        
        leaf_shader_4.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_4,ourModel_3,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        
        
        leaf_shader_4_1.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_4_1,ourModel_4_1,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        
        
        leaf_shader_5.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_5,ourModel_5,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        
        
        leaf_shader_5_1.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_5_1,ourModel_5_1,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );

        
        leaf_shader_top.Use();//---------------------
        TRANSLATION.x = -0.3f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = .3f;
        setUp_leaf_position(leaf_shader_top,ourModel_top,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );

        
        leaf_shader_down1_1.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_down1_1,ourModel_down1_1,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        

        leaf_shader_down1_2.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_down1_2,ourModel_down1_2,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        
        
        leaf_shader_down1_3.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_down1_3,ourModel_down1_3,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        

        leaf_shader_down1_4.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_down1_4,ourModel_down1_4,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        

        leaf_shader_down1_5.Use();//---------------------
        TRANSLATION.x = -0.2f;
        TRANSLATION.y = 0.0f;
        TRANSLATION.z = 0.2f;
        setUp_leaf_position(leaf_shader_down1_5,ourModel_down1_5,TRANSLATION,level_3_ON, fov, camX, camZ,  cameraPos , cameraFront,cameraUp );
        
        
        
        
        
        
        shader.Use();

        glBindVertexArray(sphereVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(sphere_downVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(cylinderVAO);
        glDrawElements(GL_TRIANGLES, 60, GL_UNSIGNED_INT, (void*)0);
        glBindVertexArray(0);

  

        glBindVertexArray(botton_1_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);

        glBindVertexArray(botton_2_VAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 27);
        glBindVertexArray(0);

        glBindVertexArray(botton_3_VAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 27);
        glBindVertexArray(0);

        glBindVertexArray(botton_4_VAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 27);
        glBindVertexArray(0);
        
        glBindVertexArray(botton_5_VAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 27);
        glBindVertexArray(0);

       //------- level 2
      
        glBindVertexArray(medium_1_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
        
        glBindVertexArray(medium_2_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
        
        glBindVertexArray(medium_3_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
        
        glBindVertexArray(medium_4_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
        
        glBindVertexArray(medium_5_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
        
 
        glBindVertexArray(top_1_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);

        glBindVertexArray(top_2_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);

        glBindVertexArray(top_3_VAO);
        glDrawArrays(GL_TRIANGLES, 0, 27);
        glBindVertexArray(0);
 

       // glActiveTexture (GL_TEXTURE1);
       // glBindTexture(GL_TEXTURE_2D, bark_texture);

        branch_shader.Use();
        glBindVertexArray(little_1_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);
        
        branch_shader.Use();
        glBindVertexArray(little_1_side_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);

        branch_shader_1.Use();

        glBindVertexArray(little_2_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);

        glBindVertexArray(little_2_side_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);
  
        
        branch_shader_2.Use();
        
        glBindVertexArray(little_3_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(little_3_side_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);


        
        branch_shader_3.Use();
        
        glBindVertexArray(little_4_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(little_4_side_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);
        

        
        branch_shader_4.Use();
        
        glBindVertexArray(little_5_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(little_5_side_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);
  

        
        leve2_branch_1.Use();
        glBindVertexArray(lev2_little_1_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);

        glBindVertexArray(lev2_little_1_side_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);

        
        leve2_branch_2.Use();
        glBindVertexArray(lev2_little_2_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);

        glBindVertexArray(lev2_little_2_side_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);

        
        leve2_branch_3.Use();
        glBindVertexArray(lev2_little_3_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(lev2_little_3_side_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);
        

        leve2_branch_4.Use();
        glBindVertexArray(lev2_little_4_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(lev2_little_4_side_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);

        
        
        leve2_branch_5.Use();
        glBindVertexArray(lev2_little_5_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);
        
        glBindVertexArray(lev2_little_5_side_VAO);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 27, 10);
        glBindVertexArray(0);

        
        
        GLfloat X_position = -0.1f ;
        GLfloat Y_position =  3.1f;
        GLfloat Z_position = 0.4f;
//        GLuint leaf_size = 500;
        leaf_shader.Use();
        leaf_positions(ourModel,  X_position, Y_position, Z_position);
        
      //  glActiveTexture (GL_TEXTURE1);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
       
        glBindTexture(GL_TEXTURE_2D, ourModel.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel.meshes.size(); i++)
        {
            
            glBindVertexArray(ourModel.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 10000);
            glBindVertexArray(0);
        }
        


        
        
        
        leaf_shader_1.Use();
        X_position = -0.1f ;
        Y_position =  3.0f;
        Z_position = 0.2f;
        
        leaf_positions(ourModel_1,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
       // ourModel.Draw(leaf_shader);
        glBindTexture(GL_TEXTURE_2D, ourModel_1.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_1.meshes.size(); i++)
        {
            
            glBindVertexArray(ourModel_1.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_1.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
 

        
        
//        level_2_1_cone[0].x = 0.8;
//        level_2_1_cone[0].y = 0.7;
//        level_2_1_cone[0].z = 0;
        leaf_shader_2.Use();
        X_position = 0.3 ;
        Y_position =  3.14f;
        Z_position = 0.4f;
        
        leaf_positions(ourModel_2,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        // ourModel.Draw(leaf_shader);
        glBindTexture(GL_TEXTURE_2D, ourModel_2.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_2.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_2.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_2.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
 
        
        leaf_shader_2_1.Use();
        X_position = 0.07 ;
        Y_position =  3.01f;
        Z_position = 0.2f;
        
        leaf_positions(ourModel_2_1,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        // ourModel.Draw(leaf_shader);
        glBindTexture(GL_TEXTURE_2D, ourModel_2_1.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_2_1.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_2_1.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_2_1.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }


        leaf_shader_3.Use();
        X_position = -0.18;
        Y_position =  3.1f;
        Z_position = -0.29f;
        
        leaf_positions(ourModel_3,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        // ourModel.Draw(leaf_shader);
        glBindTexture(GL_TEXTURE_2D, ourModel_3.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_3.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_3.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_3.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
        
  
        leaf_shader_3_1.Use();
        X_position = -0.15;
        Y_position =  3.0f;
        Z_position = -0.0f;
        
        leaf_positions(ourModel_3_1,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        // ourModel.Draw(leaf_shader);
        glBindTexture(GL_TEXTURE_2D, ourModel_3_1.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_3_1.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_3_1.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_3_1.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
        

        
        leaf_shader_4.Use();
        X_position = 0.2;
        Y_position =  3.02f;
        Z_position = -0.0f;
        
        leaf_positions(ourModel_4,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        // ourModel.Draw(leaf_shader);
        glBindTexture(GL_TEXTURE_2D, ourModel_4.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_4.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_4.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_4.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }

        
        
        leaf_shader_4_1.Use();
        X_position = 0.6;
        Y_position =  3.15f;
        Z_position = 0.05f;
        //Z_position = -0.06f;
        
        leaf_positions(ourModel_4_1,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        // ourModel.Draw(leaf_shader);
        glBindTexture(GL_TEXTURE_2D, ourModel_4_1.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_4_1.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_4_1.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_4_1.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
        
        

//        X_position = -0.18;
//        Y_position =  3.1f;
//        Z_position = -0.29f;

        
        leaf_shader_5.Use();
        X_position = 0.0;
        Y_position =  3.0f;
        Z_position = -0.1f;
        
        leaf_positions(ourModel_5,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        // ourModel.Draw(leaf_shader);
        glBindTexture(GL_TEXTURE_2D, ourModel_5.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_5.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_5.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_5.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
        
        leaf_shader_5_1.Use();
        X_position = 0.0;
        Y_position =  3.15f;
        Z_position = -0.3f;
        //Z_position = -0.06f;
        
        leaf_positions(ourModel_5_1,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        glBindTexture(GL_TEXTURE_2D, ourModel_5_1.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_5_1.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_5_1.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_5_1.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
        
        
        
        leaf_shader_top.Use();
        X_position = 0.0;
        Y_position =  3.4f;
        Z_position = 0.0f;
        //Z_position = -0.06f;
        
        leaf_positions(ourModel_top,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        glBindTexture(GL_TEXTURE_2D, ourModel_top.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_top.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_top.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_top.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }

        

        
        leaf_shader_down1_1.Use();
        X_position = .16;
        Y_position =  2.6;
        Z_position = -0.45;
        //Z_position = -0.06f;
        
        leaf_positions(ourModel_down1_1,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        glBindTexture(GL_TEXTURE_2D, ourModel_down1_1.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_down1_1.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_down1_1.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_down1_1.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
        
        
        
        leaf_shader_down1_2.Use();
        X_position = -.1;
        Y_position =  2.6;
        Z_position = -0.43;
        //Z_position = -0.06f;
        
        leaf_positions(ourModel_down1_2,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        glBindTexture(GL_TEXTURE_2D, ourModel_down1_2.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_down1_2.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_down1_2.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_down1_2.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
        
        
        
        leaf_shader_down1_3.Use();
        X_position = -.1;
        Y_position =  2.7;
        Z_position = -0.85;
        //Z_position = -0.06f;
        
        leaf_positions(ourModel_down1_3,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        glBindTexture(GL_TEXTURE_2D, ourModel_down1_3.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_down1_3.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_down1_3.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_down1_3.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
        
        leaf_shader_down1_4.Use();
        X_position = .1;
        Y_position =  2.7;
        Z_position = -0.85;
        //Z_position = -0.06f;
        
        leaf_positions(ourModel_down1_4,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        glBindTexture(GL_TEXTURE_2D, ourModel_down1_4.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_down1_4.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_down1_4.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_down1_4.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
        
        
        
        leaf_shader_down1_5.Use();
        X_position = .1;
        Y_position =  2.7;
        Z_position = -1.0f;
        //Z_position = -0.06f;
        
        leaf_positions(ourModel_down1_5,  X_position, Y_position, Z_position);
        TextureFromFile("Leaf_Alpha.png","/Users/Chiaoysbaby/desktop/tree_latest/paddle-obj",false);
        
        glBindTexture(GL_TEXTURE_2D, ourModel_down1_5.textures_loaded[0].id);
        
        for(GLuint i = 0; i < ourModel_down1_5.meshes.size(); i++)
        {
            glBindVertexArray(ourModel_down1_5.meshes[i].VAO);
            glDrawElementsInstanced(GL_TRIANGLES, ourModel_down1_5.meshes[i].indices.size(), GL_UNSIGNED_INT, 0, 500);
            glBindVertexArray(0);
        }
        
        
        
        
        glfwSwapBuffers(window);
        
        
        
    }
    
    delete_buffers();
    deletion_branches_buffer();
    deletion_medium_buffer();
    deletion_2_little_buffer();
    deletion_little_buffer();
    deletion_3_little_buffer();
    deletion_5_little_buffer();
    deletion_lev2_little_buffer();
    deletion_lev2__2_little_buffer();
    deletion_lev2__3_little_buffer();
    deletion_lev2__4_little_buffer();
    glfwTerminate();
    return 0;
    
    
}


#pragma region "User input"



void calculation_deltatime(){
    
    GLfloat currentFrame = glfwGetTime();
    deltaTime = currentFrame - lastFrame;
    lastFrame = currentFrame;
    
}





void Do_Movement()
{
    
    calculation_deltatime();
    
    // Camera controls
    GLfloat cameraSpeed = 5.0f * deltaTime;
    if (keys[GLFW_KEY_W])
        cameraPos += cameraSpeed * cameraFront;
    if (keys[GLFW_KEY_S])
        cameraPos -= cameraSpeed * cameraFront;
    if (keys[GLFW_KEY_D])
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (keys[GLFW_KEY_A])
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
}


void control_rotation(){
    if(keys[GLFW_KEY_Z]){
        printf("true \n");
        level_3_ON = true;
//        level_3_OFF = false;
    }
    if(keys[GLFW_KEY_X]){
        printf("false \n");
        //level_3_OFF = true;
        level_3_ON = false;
    }
//
//    if(keys[GLFW_KEY_C]){
//        printf("true \n");
//        level_2_ON = true;
//        //        level_3_OFF = false;
//    }
//    if(keys[GLFW_KEY_V]){
//        printf("false \n");
//        //level_3_OFF = true;
//        level_2_ON = false;
//    }



}



void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
        glfwSetWindowShouldClose(window, GL_TRUE);
    if (key >= 0 && key < 1024)
    {
        if (action == GLFW_PRESS)
            keys[key] = true;
        else if (action == GLFW_RELEASE)
            keys[key] = false;
    }
}


void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
    if (fov >= 1.0f && fov <= 45.0f)
        fov -= yoffset;
    if (fov <= 1.0f)
        fov = 1.0f;
    if (fov >= 45.0f)
        fov = 45.0f;
}

bool firstMouse = true;
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
    if (firstMouse)
    {
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }
    
    GLfloat xoffset = xpos - lastX;
    GLfloat yoffset = lastY - ypos; // Reversed since y-coordinates go from bottom to left
    lastX = xpos;
    lastY = ypos;
    
    GLfloat sensitivity = 0.05;	// Change this value to your liking
    xoffset *= sensitivity;
    yoffset *= sensitivity;
    
    yaw   += xoffset;
    pitch += yoffset;
    
    // Make sure that when pitch is out of bounds, screen doesn't get flipped
    if (pitch > 89.0f)
        pitch = 89.0f;
    if (pitch < -89.0f)
        pitch = -89.0f;
    
    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}



#pragma endregion
