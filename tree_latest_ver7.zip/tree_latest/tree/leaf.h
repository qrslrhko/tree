#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>
#include <time.h>
#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "Shader.h"

#define leaf_size 400



//#include "gl_positionVariables.h"

//GLuint amount = leaf_size;
//glm::mat4  modelMatrices[leaf_size];
//modelMatrices = new glm::mat4[amount];
//srand(glfwGetTime()); // initialize random seed
GLfloat L_radius = .1f;
GLfloat offset = .05f;


//GLuint X_position = -0.1f ;
//GLuint Y_position =  3.1f;
//GLuint Z_position = 0.4f;
//

void leaf_positions(Model our_model, GLfloat X_position,GLfloat Y_position,GLfloat Z_position){
    
    
    GLuint amount = leaf_size;
    glm::mat4  modelMatrices[leaf_size];
    
    
    
   
    srand(glfwGetTime()*0.8);
    for(GLuint i = 0; i < amount; i++)
    {
        glm::mat4 model;
        // 1. Translation: Randomly displace along circle with radius 'radius' in range [-offset, offset]
        GLfloat angle = (GLfloat)i / (GLfloat)amount * 360.0f;
        GLfloat displacement = (rand() % (GLint)(2 * offset * 100)) / 100.0f - offset;
        GLfloat x = X_position +  sin(angle) * L_radius + displacement;
        displacement = (rand() % (GLint)(2 * offset * 100)) / 100.0f - offset;
        GLfloat y = Y_position  - 2.5f + displacement * 0.4f; // Keep height of asteroid field smaller compared to width of x and z
        displacement = (rand() % (GLint)(2 * offset * 100)) / 100.0f - offset;
        GLfloat z = Z_position + cos(angle) * L_radius + displacement;
        model = glm::translate(model, glm::vec3(x, y, z));
        
        // 2. Scale: Scale between 0.05 and 0.25f
        GLfloat scale = (rand() % 20) / 100.0f + 0.05;
        model = glm::scale(model, glm::vec3(scale));
        
        // 3. Rotation: add random rotation around a (semi)randomly picked rotation axis vector
        GLfloat rotAngle = (rand() % 360);
        model = glm::rotate(model, rotAngle, glm::vec3(0.4f, 0.6f, 0.8f));
        
        // 4. Now add to list of matrices
        modelMatrices[i] = model;
    }
    
    
 /*
    glm::mat4 model1;
    
    model1  = glm::translate(model1, glm::vec3(2.3f, 1.4f, -2.0f));
    model1 = glm::scale(model1, glm::vec3(0.005f, 0.01f, 0.009f));

    modelMatrices[0] = model1;
    
    model1  = glm::translate(model1, glm::vec3(-5.3f, 0.3f, 1.0f));
    model1 = glm::scale(model1, glm::vec3(0.005f, 0.01f, 0.009f));
    modelMatrices[1] = model1;
    
    model1  = glm::translate(model1, glm::vec3(1.3f, -1.3f, 1.5f));
    model1 = glm::scale(model1, glm::vec3(0.005f, 0.01f, 0.009f));
    modelMatrices[2] = model1;
 */
    // forward declare the buffer
    GLuint Leaf_buffer;
    glGenBuffers(1, &Leaf_buffer);
    glBindBuffer(GL_ARRAY_BUFFER, Leaf_buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(modelMatrices), modelMatrices, GL_STATIC_DRAW);
    
  
    int j = 0;
    for(GLuint i = 0; i < our_model.meshes.size(); i++)
    {
       // printf("j: %d  \n",j);
        GLuint VAO = our_model.meshes[i].VAO;
        //j++;
        glBindVertexArray(VAO);
        // Set attribute pointers for matrix (4 times vec4)
        glEnableVertexAttribArray(3);
        glVertexAttribPointer(3, 4, GL_FLOAT, GL_FALSE, sizeof(glm::mat4), (GLvoid*)0);
        glEnableVertexAttribArray(4);
        glVertexAttribPointer(4, 4, GL_FLOAT, GL_FALSE, sizeof(glm::mat4), (GLvoid*)(sizeof(glm::vec4)));
        glEnableVertexAttribArray(5);
        glVertexAttribPointer(5, 4, GL_FLOAT, GL_FALSE, sizeof(glm::mat4), (GLvoid*)(2 * sizeof(glm::vec4)));
        glEnableVertexAttribArray(6);
        glVertexAttribPointer(6, 4, GL_FLOAT, GL_FALSE, sizeof(glm::mat4), (GLvoid*)(3 * sizeof(glm::vec4)));
        
        glVertexAttribDivisor(3, 1);
        glVertexAttribDivisor(4, 1);
        glVertexAttribDivisor(5, 1);
        glVertexAttribDivisor(6, 1);
        
        glBindVertexArray(0);
        
    }
   
    
}