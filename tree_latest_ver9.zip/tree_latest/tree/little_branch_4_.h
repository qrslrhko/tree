#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>


#define sides 11
#define little_4_radius 0.02


glm::vec3 little_1_4_cone[500];
glm::vec3 little_1_4_side_cone[500];

glm::vec3 little_cone_4[500];
glm::vec3 little_cone_side_4[500];

GLuint little_4_VBO,little_4_VAO;
GLuint little_4_side_VBO,little_4_side_VAO;

glm::vec3 translations_4[100];
GLuint instance_4_VBO;


int little_4_count_side = 0;

//outer.z = 0.44f + outer.z  + little_4_radius * cos(rad);
//outer.y =  0.08f + outer.y + little_4_radius * sin(rad);
//outer.x = 0.2f + outer.x ;


void make_instance_4(){
    translations_4[0].x = 0.1f;
    translations_4[0].y = 0.04f;
    translations_4[0].z = 0.3f;
    //
    translations_4[1].x = 0.18f;
    translations_4[1].y = 0.06;
    translations_4[1].z = 0.5;
    //
    //    translations_3[2].x = -0.4;
    //    translations_3[2].y = -0.04;
    //    translations_3[2].z = 0.05;
    //
    //    translations[3].x = 1.33;
    //    translations[3].y = 0.12;
    //    translations[3].z = 1.02;
    
    
    glGenBuffers(1, &instance_4_VBO);
    glBindBuffer(GL_ARRAY_BUFFER, instance_4_VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(translations_4), translations_4, GL_STATIC_DRAW);
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    
}



void little_cone_level_1_4(){
    
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    little_4_count_side = 0;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    little_1_4_cone[0].x = 0.3;
    little_1_4_cone[0].y = 0.13;
    little_1_4_cone[0].z = 0.2;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = 0.44f + outer.z  + little_4_radius * cos(rad);
        outer.y =  0.08f + outer.y + little_4_radius * sin(rad);
        outer.x = 0.2f + outer.x ;
        
        little_1_4_cone[idx++] = outer;
        little_4_count_side++;
    }
    //
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
   // printf("idx+2: %d ",idx + 2);
    while (count_cone < little_4_count_side) {
        idx = count_cone * 3;
        little_cone_4[idx+0] = little_1_4_cone[0];
        little_cone_4[idx+1] = little_1_4_cone[i];
        little_cone_4[idx+2] = little_1_4_cone[j];
        i++;
        j++;
        count_cone++;
    }
    
    
    little_cone_texture();
    make_instance_4();
    
    
    glGenVertexArrays(1, &little_4_VAO);
    glGenBuffers(1,&little_4_VBO);
    glBindVertexArray(little_4_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,little_4_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(little_cone_4) ,little_cone_4, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(1);  // texture coords
    glBindBuffer(GL_ARRAY_BUFFER, little_cone_texture_VBO);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ARRAY_BUFFER, instance_4_VBO);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    
    glVertexAttribDivisor(2, 1);
    // Tell OpenGL this is an instanced vertex attribute.
    //
    glBindVertexArray(0);
    
    
}





void little_cone_level_1_4_other_side(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    little_4_count_side = 0;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    little_1_4_side_cone[0].x = -0.02;
    little_1_4_side_cone[0].y = 0.12;
    little_1_4_side_cone[0].z = 0.3;
    

    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = 0.44f + outer.z  + little_4_radius * cos(rad);
        outer.y =  0.08f + outer.y + little_4_radius * sin(rad);
        outer.x = 0.2f + outer.x ;

        
        
        little_1_4_side_cone[idx++] = outer;
        little_4_count_side++;
    }
    
    
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
   // printf("little: %d \n ", little_count_side);
    while (count_cone < little_4_count_side) {
        idx = count_cone * 3;
        little_cone_side_4[idx+0] = little_1_4_side_cone[0];
        little_cone_side_4[idx+1] = little_1_4_side_cone[i];
        little_cone_side_4[idx+2] = little_1_4_side_cone[j];
        //printf("idx: %d \n ",idx);
        i++;
        j++;
        count_cone++;
    }
    
    little_cone_texture();
    make_instance_4();
    
    
    glGenVertexArrays(1, &little_4_side_VAO);
    glGenBuffers(1,&little_4_side_VBO);
    glBindVertexArray(little_4_side_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,little_4_side_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(little_cone_side_4) ,little_cone_side_4, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(3);  // texture coords
    glBindBuffer(GL_ARRAY_BUFFER, little_cone_texture_VBO);
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ARRAY_BUFFER,instance_4_VBO);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    //  glBindBuffer(GL_ARRAY_BUFFER, 0);
    
    
    glVertexAttribDivisor(2, 1); // Tell OpenGL this is an instanced vertex attribute.
    
    glBindVertexArray(0);
    
}





void deletion_4_little_buffer(){
    
    glDeleteBuffers(1,&little_4_VBO);
    glDeleteBuffers(1,&little_4_VAO);
    glDeleteBuffers(1,&little_4_side_VBO);
    glDeleteBuffers(1,&little_4_side_VAO);
    
    glDeleteBuffers(1,&instance_4_VBO);
}






