

#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>



#define sides 11
#define radius 0.05

int count_side = 0;
//float radius = 0.05f;


glm::vec3 botton_buffer[500];
glm::vec3 cone[500];
GLuint botton_VBO, botton_VAO;


void botton_circle(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    int count = 0;
    int outerVertexCount = vertexCount-1;
    botton_buffer[0].x = 1.2;
    botton_buffer[0].y = 0.5;
    botton_buffer[0].z = 0;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = .01f + outer.z  + radius * cos(rad);
        //        outer.y = outer.y + radius * sin(rad);
        
//        outer.y = outer.y + -1.0f;
        //        outer.z = outer.z + 0;
        outer.y =  outer.y + radius * sin(rad);
        
        outer.x = outer.x ;
        
        botton_buffer[idx++] = outer;
        count_side++;
    }
 
    botton_buffer[idx] = botton_buffer[1];
    printf("idx: %d  \n ", idx);
    
    
    
    
    printf("count_side: %d \n", count_side);
    idx = 0;
    count = 0;
    int i = 1;
    int j = 2;
    while (count < count_side) {
        
        
        idx = count * 3;
        cone[idx + 0] = botton_buffer[0];
        cone[idx + 1] = botton_buffer[i];
        cone[idx + 2] = botton_buffer[j];
        
      //  printf("i: %d , j: %d \n",i,j);
      //  printf("%d,%d,%d  \n", idx+0, idx+1, idx+2);
        
        
        i++;
        j++;
       
        count ++;
    }
    
    
    
}


void cone_buffer(){
    
    glGenVertexArrays(1, &botton_VAO);
    glGenBuffers(1,&botton_VBO);
    glBindVertexArray(botton_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,botton_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(botton_buffer) ,botton_buffer, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    
    
}

void deletion_branches_buffer(){
    
    glDeleteBuffers(1,&botton_VAO);
    glDeleteBuffers(1,&botton_VBO);
}

