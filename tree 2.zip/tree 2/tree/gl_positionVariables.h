
#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "Shader.h"

void setUp_gl_position( Shader shader){
    
    GLint projectMat = glGetUniformLocation(shader.Program,"projection_matrix");
    GLint viewMat = glGetUniformLocation(shader.Program,"view_matrix");
    GLint modelMat = glGetUniformLocation(shader.Program,"model_matrix");
    
    
    GLfloat radius = 10.0f;
    GLfloat camX = sin(glfwGetTime()) * radius;
    GLfloat camZ = cos(glfwGetTime()) * radius;
    // view matrix
    glm::mat4 view;
    view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
    //        view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
    //        glm::mat4 view_matrix = glm::lookAt(glm::vec3(0, 4, 4), glm::vec3(0, 0, 0), glm::vec3(0, 0, 1));
    glm::mat4 view_matrix  = view;
    //        glm :: mat4 view_matrix = glm::lookAt(glm::vec3(0.0f, 0.0f, 3.0f),
    //        glm::vec3(0.0f, 0.0f, 0.0f),
    //        glm::vec3(0.0f, 1.0f, 0.0f));
    
    
    // projection matrx
    glm::mat4 projection_matrix = glm::perspective(56.25f, 16.0f/9.0f, 0.1f, 100.0f);
    
    
    // model matrix
    glm::mat4 model_matrix; // identity
    
    glUniformMatrix4fv(projectMat, 1, GL_FALSE, glm::value_ptr(projection_matrix));
    glUniformMatrix4fv(viewMat, 1, GL_FALSE, glm::value_ptr(view_matrix));
    glUniformMatrix4fv(modelMat, 1, GL_FALSE, glm::value_ptr(model_matrix));
    
}





