#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>


#define sides 11
#define little_5_radius 0.02


glm::vec3 little_1_5_cone[500];
glm::vec3 little_1_5_side_cone[500];

glm::vec3 little_cone_5[500];
glm::vec3 little_cone_side_5[500];

GLuint little_5_VBO,little_5_VAO;
GLuint little_5_side_VBO,little_5_side_VAO;

glm::vec3 translations_5[100];
GLuint instance_5_VBO;


int little_5_count_side = 0;

//outer.z = 0.0f + outer.z  + little_5_radius * cos(rad);
//outer.y =  0.07f + outer.y + little_5_radius * sin(rad);
//outer.x = .2f + outer.x ;

void make_instance_5(){
    translations_5[0].x = .02f;
    translations_5[0].y = 0.04f;
    translations_5[0].z = -.2f ;
//    //
    translations_5[1].x = 0.04f;
    translations_5[1].y = 0.07;
    translations_5[1].z = -0.5f;
//    //
//    outer.z = -.3f + outer.z  + little_5_radius * cos(rad);
//    outer.y =  0.07f + outer.y + little_5_radius * sin(rad);
//    outer.x = -.05f + outer.x ;
    //
    //    translations[3].x = 1.33;
    //    translations[3].y = 0.12;
    //    translations[3].z = 1.02;
    
    
    glGenBuffers(1, &instance_5_VBO);
    glBindBuffer(GL_ARRAY_BUFFER, instance_5_VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(translations_5), translations_5, GL_STATIC_DRAW);
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    
}



void little_cone_level_1_5(){
    
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    little_5_count_side = 0;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    little_1_5_cone[0].x = .3f;
    little_1_5_cone[0].y = 0.1f;
    little_1_5_cone[0].z = -0.35f;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = -.3f + outer.z  + little_5_radius * cos(rad);
        outer.y =  0.07f + outer.y + little_5_radius * sin(rad);
        outer.x = .02f + outer.x ;
//        outer.z = 0.0f + outer.z  + little_5_radius * cos(rad);
//        outer.y =  0.07f + outer.y + little_5_radius * sin(rad);
//        outer.x = .2f + outer.x ;
        little_1_5_cone[idx++] = outer;
        little_5_count_side++;
    }
    //
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
  //  printf("idx+2: %d ",idx + 2);
    while (count_cone < little_5_count_side) {
        idx = count_cone * 3;
        little_cone_5[idx+0] = little_1_5_cone[0];
        little_cone_5[idx+1] = little_1_5_cone[i];
        little_cone_5[idx+2] = little_1_5_cone[j];
        i++;
        j++;
        count_cone++;
    }
    
    
    little_cone_texture();
    make_instance_5();
    
    
    glGenVertexArrays(1, &little_5_VAO);
    glGenBuffers(1,&little_5_VBO);
    glBindVertexArray(little_5_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,little_5_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(little_cone_5) ,little_cone_5, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(1);  // texture coords
    glBindBuffer(GL_ARRAY_BUFFER, little_cone_texture_VBO);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ARRAY_BUFFER, instance_5_VBO);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
 
    glVertexAttribDivisor(2, 1);

    
    // Tell OpenGL this is an instanced vertex attribute.

    glBindVertexArray(0);
    
    
}

void little_cone_level_1_5_other_side(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    little_5_count_side = 0;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    little_1_5_side_cone[0].x = -0.3;
    little_1_5_side_cone[0].y = 0.15f;
    little_1_5_side_cone[0].z = -0.3f;
    

    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = -.3f + outer.z  + little_5_radius * cos(rad);
        outer.y =  0.07f + outer.y + little_5_radius * sin(rad);
        outer.x = .02f + outer.x ;

        
        
        
        little_1_5_side_cone[idx++] = outer;
        little_5_count_side++;
    }
    
    
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
    //printf("little: %d \n ", little_count_side);
    while (count_cone < little_5_count_side) {
        idx = count_cone * 3;
        little_cone_side_5[idx+0] = little_1_5_side_cone[0];
        little_cone_side_5[idx+1] = little_1_5_side_cone[i];
        little_cone_side_5[idx+2] = little_1_5_side_cone[j];
      //  printf("idx: %d \n ",idx);
        i++;
        j++;
        count_cone++;
    }
    
    little_cone_texture();
    make_instance_5();
    
    
    glGenVertexArrays(1, &little_5_side_VAO);
    glGenBuffers(1,&little_5_side_VBO);
    glBindVertexArray(little_5_side_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,little_5_side_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(little_cone_side_5) ,little_cone_side_5, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(3);  // texture coords
    glBindBuffer(GL_ARRAY_BUFFER, little_cone_texture_VBO);
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ARRAY_BUFFER,instance_5_VBO);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    //  glBindBuffer(GL_ARRAY_BUFFER, 0);
    
    
    glVertexAttribDivisor(2, 1); // Tell OpenGL this is an instanced vertex attribute.
    
    glBindVertexArray(0);
    
}



void deletion_5_little_buffer(){
    
    glDeleteBuffers(1,&little_5_VBO);
    glDeleteBuffers(1,&little_5_VAO);
    glDeleteBuffers(1,&little_5_side_VBO);
    glDeleteBuffers(1,&little_5_side_VAO);
    
    glDeleteBuffers(1,&instance_5_VBO);
}



