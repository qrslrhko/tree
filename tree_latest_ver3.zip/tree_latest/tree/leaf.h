#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "Shader.h"

#include "Camera.h"

//#include "gl_positionVariables.h"




void leaf_positions(Shader shader){
    
    glm::mat4 projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
    //glm::mat4 view = camera.GetViewMatrix();
    glm::mat4  view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
    
    glUniformMatrix4fv(glGetUniformLocation(shader.Program, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
    glUniformMatrix4fv(glGetUniformLocation(shader.Program, "view"), 1, GL_FALSE, glm::value_ptr(view));
    
    // Draw the loaded model
    glm::mat4 model;
    model = glm::translate(model, glm::vec3(0.0f, -1.75f, 0.0f));
    // model = glm::translate(model, glm::vec3(0.0f, -1.75f, 0.0f));// Translate it down a bit so it's at the center of the scene
    //model = glm::scale(model, glm::vec3(0.0002f, 0.002f, 0.002f));
     model = glm::scale(model, glm::vec3(0.2f, 0.2f, 0.2f));
    // It's a bit too big for our scene, so scale it down
    glUniformMatrix4fv(glGetUniformLocation(shader.Program, "model"), 1, GL_FALSE, glm::value_ptr(model));
    
    
    
    
//    //projection
//    glm::mat4 projection = glm::perspective(fov, (GLfloat)WIDTH/(GLfloat)HEIGHT, 0.1f, 100.0f);
//    
//    glUniformMatrix4fv(glGetUniformLocation(shader.Program, "projection"), 1, GL_FALSE, glm::value_ptr(projection));
//    
    
//    //view
//    glm:: mat4 view;
//    GLfloat leaf_radius = 5.0f;
//    GLfloat camX = sin(glfwGetTime())*0.5 * leaf_radius;
//    GLfloat camZ = cos(glfwGetTime())*0.5 * leaf_radius;
//   
//    //view = glm::lookAt(glm::vec3(camX, 0.0, camZ), glm::vec3(0.0, 0.0, 0.0), glm::vec3(0.0, 1.0, 0.0));
//     view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
//    glUniformMatrix4fv(glGetUniformLocation(shader.Program, "view"), 1, GL_FALSE, glm::value_ptr(view));
//
//    
//    //model
//    glm::mat4 model;
//   // model = glm::translate(model, glm::vec3(0.0f, -1.75f, 0.0f));
//     model = glm::translate(model, glm::vec3(0.0f, -1.75f, 0.0f));
//    // Translate it down a bit so it's at the center of the scene
//    model = glm::scale(model, glm::vec3(0.03f, 0.3f, 0.3f));
//    // It's a bit too big for our scene, so scale it down
//    glUniformMatrix4fv(glGetUniformLocation(shader.Program, "model"), 1, GL_FALSE, glm::value_ptr(model));
//    
    
}