#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>



#define sides 11
#define little_radius 0.02


glm::vec3 little_1_1_cone[500];
glm::vec3 little_1_1_side_cone[500];

//
//glm::vec3 little_1_2_cone[500];
//glm::vec3 little_1_2_side_cone[500];

glm::vec3 little_cone_1[500];
glm::vec3 little_cone_side_1[500];

//glm::vec3 little_cone_2[500];
//glm::vec3 little_cone_side_2[500];
//
//glm::vec3 little_cone_2_copy[500];


GLuint little_1_VBO,little_1_VAO;
GLuint little_1_side_VBO,little_1_side_VAO;


//GLuint little_2_VBO,little_2_VAO;
//GLuint little_2_side_VBO,little_2_side_VAO;
//

glm::vec3 little_texture_cone_buffer[500];
GLuint little_cone_texture_VBO;


glm::vec3 translations[100];
GLuint instanceVBO;


//glm::vec3 translations_2[100];
//GLuint instance_2_VBO;
//




int little_count_side = 0;


void little_cone_texture(){
    
    int in_count = 0;
    int index = 0;
    while (in_count < little_count_side) {
        index = in_count * 3;
        little_texture_cone_buffer[index +0 ].x =1.0f;
        little_texture_cone_buffer[index +0 ].y =0.0f;
        
        little_texture_cone_buffer[index + 1].x =0.5f;
        little_texture_cone_buffer[index + 1].y =1.0f;
        
        little_texture_cone_buffer[index + 2].x =0.0f;
        little_texture_cone_buffer[index + 2].y =0.0f;
        in_count++;
        
    }
    
    
    // texture array buffer
    glGenBuffers(1,&little_cone_texture_VBO);
    glBindBuffer(GL_ARRAY_BUFFER,little_cone_texture_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(little_texture_cone_buffer),little_texture_cone_buffer, GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    
}

void make_instance(){
    
   // printf("instance \n");
    
    translations[0].x = 0.25;
    translations[0].y = 0.08;
    translations[0].z = 0.003;
    
    translations[1].x = -0.3;
    translations[1].y = -0.05;
    translations[1].z = 0.025;
//
    translations[2].x = -0.4;
    translations[2].y = -0.08;
    translations[2].z = 0.05;
//
//    translations[3].x = 1.33;
//    translations[3].y = 0.12;
//    translations[3].z = 1.02;

    
    glGenBuffers(1, &instanceVBO);
    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(translations), translations, GL_STATIC_DRAW);
  //  glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * 1, &translations[0], GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    
}


void little_cone_level_1_1(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    little_count_side = 0;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    little_1_1_cone[0].x = .9;
    little_1_1_cone[0].y = .15;
    little_1_1_cone[0].z = 0.3;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = .02f + outer.z  + little_radius * cos(rad);
        //        outer.y = outer.y + radius * sin(rad);
        
        //        outer.y = outer.y + -1.0f;
        //        outer.z = outer.z + 0;
        outer.y = 0.12f + outer.y + little_radius * sin(rad);
        
        outer.x = 0.53f + outer.x ;
        
        little_1_1_cone[idx++] = outer;
        little_count_side++;
    }
    
    
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
    
    while (count_cone < little_count_side) {
        idx = count_cone * 3;
        little_cone_1[idx+0] = little_1_1_cone[0];
        little_cone_1[idx+1] = little_1_1_cone[i];
        little_cone_1[idx+2] = little_1_1_cone[j];
        
        i++;
        j++;
        count_cone++;
    }
   

  
    little_cone_texture();
    make_instance();
    
    
    glGenVertexArrays(1, &little_1_VAO);
    glGenBuffers(1,&little_1_VBO);
    glBindVertexArray(little_1_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,little_1_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(little_cone_1) ,little_cone_1, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(1);  // texture coords
    glBindBuffer(GL_ARRAY_BUFFER, little_cone_texture_VBO);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ARRAY_BUFFER, instanceVBO);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    glVertexAttribDivisor(2, 1); // Tell OpenGL this is an instanced vertex attribute.

    glBindVertexArray(0);
    
}


void little_cone_level_1_1_other_side(){
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 1;
    little_count_side = 0;
    //    int count = 0;
    int outerVertexCount = vertexCount-1;
    little_1_1_side_cone[0].x = .49;
    little_1_1_side_cone[0].y = .17;
    little_1_1_side_cone[0].z = -0.3;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.z = .02f + outer.z  + little_radius * cos(rad);
        //        outer.y = outer.y + radius * sin(rad);
        
        //        outer.y = outer.y + -1.0f;
        //        outer.z = outer.z + 0;
        outer.y = 0.12f + outer.y + little_radius * sin(rad);
        
        outer.x = 0.53f + outer.x ;
        
        little_1_1_side_cone[idx++] = outer;
        little_count_side++;
    }
    
    
    idx = 0;
    int count_cone = 0;
    int i = 1;
    int j = 2;
    printf("little: %d \n ", little_count_side);
    while (count_cone < little_count_side) {
        idx = count_cone * 3;
        little_cone_side_1[idx+0] = little_1_1_side_cone[0];
        little_cone_side_1[idx+1] = little_1_1_side_cone[i];
        little_cone_side_1[idx+2] = little_1_1_side_cone[j];
         printf("idx: %d \n ",idx);
        i++;
        j++;
        count_cone++;
    }
    
    little_cone_texture();
     make_instance();
    
    
    glGenVertexArrays(1, &little_1_side_VAO);
    glGenBuffers(1,&little_1_side_VBO);
    glBindVertexArray(little_1_side_VAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,little_1_side_VBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(little_cone_side_1) ,little_cone_side_1, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    
    glEnableVertexAttribArray(3);  // texture coords
    glBindBuffer(GL_ARRAY_BUFFER, little_cone_texture_VBO);
    glVertexAttribPointer(3, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    

    glEnableVertexAttribArray(2);
    glBindBuffer(GL_ARRAY_BUFFER,instanceVBO);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    //  glBindBuffer(GL_ARRAY_BUFFER, 0);
    
    
    glVertexAttribDivisor(2, 1); // Tell OpenGL this is an instanced vertex attribute.

    glBindVertexArray(0);
    
}
//
//
//void make_instance_2(){
//    
//    // printf("instance \n");
//    
//    translations_2[0].x = 1.25;
//    translations_2[0].y = 0.08;
//    translations_2[0].z = 0.003;
//    
//    translations_2[1].x = -1.5;
//    translations_2[1].y = -0.05;
//    translations_2[1].z = 0.025;
//    //
////    translations_2[2].x = -0.4;
////    translations_2[2].y = -0.04;
////    translations_2[2].z = 0.05;
//    //
//    //    translations[3].x = 1.33;
//    //    translations[3].y = 0.12;
//    //    translations[3].z = 1.02;
//    
//    
//    glGenBuffers(1, &instance_2_VBO);
//    glBindBuffer(GL_ARRAY_BUFFER, instance_2_VBO);
//    glBufferData(GL_ARRAY_BUFFER, sizeof(translations_2), translations_2, GL_STATIC_DRAW);
//    //  glBufferData(GL_ARRAY_BUFFER, sizeof(glm::vec3) * 1, &translations[0], GL_STATIC_DRAW);
//    glBindBuffer(GL_ARRAY_BUFFER, 0);
//    
//}
//
//
//void little_cone_level_1_2(){
//    int vertexCount = sides;
//    float PI = 3.1425;
//    int idx = 1;
//    little_count_side = 0;
//    //    int count = 0;
//    int outerVertexCount = vertexCount-1;
//    little_1_2_cone[0].x = -0.6;
//    little_1_2_cone[0].y = 0.3;
//    little_1_2_cone[0].z = -0.8;
//    
//    for (int i = 0; i < outerVertexCount; ++i){
//        float percent = (i / (float) (outerVertexCount-1));
//        float rad = percent * 2*PI;
//
//        //Vertex position
//        glm::vec3 outer;
//        outer.z = .01f + outer.z  + little_radius * cos(rad);
//        outer.y = 0.05f + outer.y + little_radius * sin(rad);
//        outer.x = -.4f + outer.x ;
//        
//        little_1_2_cone[idx++] = outer;
//        little_count_side++;
//    }
////    
//    idx = 0;
//    int count_cone = 0;
//    int i = 1;
//    int j = 2;
//     printf("idx+2: %d ",idx + 2);
//    while (count_cone < little_count_side) {
//        idx = count_cone * 3;
//        little_cone_2[idx+0] = little_1_2_cone[0];
//        little_cone_2[idx+1] = little_1_2_cone[i];
//        little_cone_2[idx+2] = little_1_2_cone[j];
//                 i++;
//        j++;
//        count_cone++;
//    }
// 
//    
//    little_cone_texture();
//    make_instance_2();
//    
//    
//    glGenVertexArrays(1, &little_2_VAO);
//    glGenBuffers(1,&little_2_VBO);
//    glBindVertexArray(little_2_VAO);
//    
//    glBindBuffer(GL_ARRAY_BUFFER,little_2_VBO);
//    glBufferData(GL_ARRAY_BUFFER,sizeof(little_cone_2) ,little_cone_2, GL_STATIC_DRAW);
//    
//    glEnableVertexAttribArray(0);
//    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
//    
//    
//    glEnableVertexAttribArray(5);  // texture coords
//    glBindBuffer(GL_ARRAY_BUFFER, little_cone_texture_VBO);
//    glVertexAttribPointer(5, 2, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
//    
////   
//    glEnableVertexAttribArray(6);
//    glBindBuffer(GL_ARRAY_BUFFER, instance_2_VBO);
//    glVertexAttribPointer(6, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
////
////    
////    
////    glVertexAttribDivisor(5, 1); // Tell OpenGL this is an instanced vertex attribute.
////   
//    glBindVertexArray(0);
//    
//}



void deletion_little_buffer(){
    
    glDeleteBuffers(1,&little_1_VBO);
    glDeleteBuffers(1,&little_1_VAO);
    glDeleteBuffers(1,&little_1_side_VAO);
    glDeleteBuffers(1,&little_1_side_VBO);
   
    glDeleteBuffers(1,& little_cone_texture_VBO);
    glDeleteBuffers(1,&instanceVBO);
   
}




