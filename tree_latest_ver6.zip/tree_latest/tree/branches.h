
#include <GL/glew.h>
#include <glut/glut.h>
#include <iostream>

#include <GLFW/glfw3.h>
#include "glm/glm.hpp"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#define sides 11



int temp = 0;

void DrawCylinder(float thickness, float radius, float length) {
    
    float x = 0;
    float y = 0;
    float angle = 0.0;
    float angle_stepsize = 0.1;
    
    float pi = 3.1415025;
    
    angle = 0.0;
    while (angle < 2 * pi) {
//        glm::vec3 outer;
        x = radius * cos(angle);
        y = radius * sin(angle);
        
        glVertex3f(x, y, thickness / length);
        glVertex3f(x, y, 0);
        angle = angle + angle_stepsize;
        
    }
    
    glVertex3f(radius, 0.0, thickness / length);
    glVertex3f(radius, 0.0, 0);
    
    
    
}

//glm::vec2 buffer[60];

glm::vec3 buffer[500];
glm::vec3 buffer_down[500];

glm::vec3 buffer_cylinder[500];
GLuint cylinder_indices[500];


glm::vec2 texture_buffer[500];


float up_0=0;
float up_1=0;

float down_0=0;
float down_1=0;

GLuint sphereVBO, sphereVAO;
GLuint sphere_downVBO, sphere_downVAO;
GLuint cylinderVBO, cylinderVAO, cylinder_indices_VBO, cylinder_texture_VBO;

int branch_count = 0;
float radius = 0.05f;



void upper_circle(){

    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 0;

    int outerVertexCount = vertexCount-1;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.x = outer.x  + radius * cos(rad);
//        outer.y = outer.y + radius * sin(rad);
        if(i == 0){
            up_0 = radius * cos(rad);
        }
        
        outer.y = outer.y + -1.0f;
//        outer.z = outer.z + 0;
        outer.z = outer.z + radius * sin(rad);
        
        if(i == 0){
            up_1 = radius * sin(rad);
        }
        
        buffer[idx++] = outer;
        branch_count++;
    }
    
}

void UpperCircle_buffer(){
    
//    upper_circle();
//    GLuint sphereVBO, sphereVAO;
    
    glGenVertexArrays(1, &sphereVAO);
    glGenBuffers(1,&sphereVBO);
    glBindVertexArray(sphereVAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,sphereVBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(buffer) , buffer, GL_STATIC_DRAW);
//    glBufferData(GL_ARRAY_BUFFER,sizeof(glm::vec3) * 120 ,&buffer[0], GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    
}


void down_circle(){
    
    
    //float radius = 1.0f;
    // float center_x = 0.0f;
    // float center_y = 0.0f;
    int vertexCount = sides;
    float PI = 3.1425;
    int idx = 0;

    int outerVertexCount = vertexCount-1;
    
    for (int i = 0; i < outerVertexCount; ++i){
        float percent = (i / (float) (outerVertexCount-1));
        float rad = percent * 2*PI;
        
        //Vertex position
        glm::vec3 outer;
        outer.x = outer.x  + radius * cos(rad);
        //        outer.y = outer.y + radius * sin(rad);
        if(i == 0){
            down_0 = radius * cos(rad);
        }
        outer.y = outer.y + 1.0f;
        //        outer.z = outer.z + 0;
        outer.z = outer.z + radius * sin(rad);
        if(i == 0){
            down_1 = radius * sin(rad);
        }
        buffer_down[idx++] = outer;
        
    }
    
}

void DownCircle_buffer(){
    
    //    upper_circle();
    //    GLuint sphereVBO, sphereVAO;
    
    glGenVertexArrays(1, &sphere_downVAO);
    glGenBuffers(1,&sphere_downVBO);
    glBindVertexArray(sphere_downVAO);
    
    glBindBuffer(GL_ARRAY_BUFFER,sphere_downVBO);
//    glBufferData(GL_ARRAY_BUFFER,sizeof(glm::vec3) * 120 ,&buffer_down[0], GL_STATIC_DRAW);

    glBufferData(GL_ARRAY_BUFFER,sizeof(buffer_down) ,buffer_down, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    
}

void cylinder(){
    
    int i = 0;
    int j = 1;
//    int k = 0;
    int in_count = 0;
    int index = 0;
//    buffer_cylinder[0] = buffer[0];
//    buffer_cylinder[1] = buffer_down[0];
//    buffer_cylinder[2] = buffer[1];
//    buffer_cylinder[3] = buffer_down[1];
//    
    
    while (in_count < branch_count) {
     //   printf("in_count: %d --------: %d \n", in_count, index);
        index  = 2 * in_count;

        buffer_cylinder[index+0] = buffer[i];
        buffer_cylinder[index+1] = buffer_down[i];
//        buffer_cylinder[index+2] = buffer[i+1];
//        buffer_cylinder[index+3] = buffer_down[i+1];
       // printf("index: %d      ", index + 0);
       // printf("index: %d \n", index + 1);
     
//        i++;
//        j++;
        i = i+1;
        in_count++;
    }
  
//    GLuint cylinder_indices[]={0,1,2,2,1,3};
    in_count = 0;
    index = 0;
    i = 0;
  //  printf("\n");
    //printf("\n");
    while (in_count< branch_count) {
//        printf("i: %d \n", i);
        index = 6 * in_count;
        cylinder_indices[index + 0] = i+0;
        cylinder_indices[index + 1] = i+1;
        cylinder_indices[index + 2] = i+2;
        
        cylinder_indices[index + 3] = i+2;
        cylinder_indices[index + 4] = i+1;
        cylinder_indices[index + 5] = i+3;
       // printf("%d, %d, %d, %d, %d, %d \n", i+0,i+1, i+2, i+2 , i+1, i+3);
//        index = 6 * in_count;
        i = i + 2;
        in_count++;
    
    }
//    printf("\n");
//    printf("\n");
//    printf("how many indices: %d \n", (count-1)*6 );
//    printf("\n");
//    printf("\n");
    // indices for cylinder-------
    
    
//    while(in_count < count){
//        
//        buffer_cylinder[index+0] = buffer[i]; //0
//        buffer_cylinder[index+1] = buffer_down[i]; //1
//        buffer_cylinder[index+2] = buffer[j];//2
//        
//        buffer_cylinder[index+3] = buffer[j];//2
//        buffer_cylinder[index+4] = buffer_down[i];//1
//        buffer_cylinder[index+5] = buffer_down[j];//3
//        index = 6 * in_count;
//        i++;
//        j++;
//        in_count++;
//    }
//    printf("count: %d \n",count);
//    printf("\n");
//    printf("\n");
//    buffer_cylinder[0] = buffer[0];
//    buffer_cylinder[1] = buffer_down[0];
//    buffer_cylinder[2] = buffer[1];
//    
//    buffer_cylinder[3] = buffer[1];
//    buffer_cylinder[4] = buffer_down[0];
//    buffer_cylinder[5] = buffer_down[1];
//    
//    
//    buffer_cylinder[6] = buffer[1];
//    buffer_cylinder[7] = buffer_down[1];
//    buffer_cylinder[8] = buffer[2];
//    
//    buffer_cylinder[9] = buffer[2];
//    buffer_cylinder[10] = buffer_down[1];
//    buffer_cylinder[11] = buffer_down[2];
//    printf("count: %d  \n ", count);
    
}
//GLuint cylinder_indices[]={0,1,2,2,1,3};
void blind_texture(){
   // texture_buffer = {1.0f, 1.0f,  1.0f, 0.0f,  0.0f, 0.0f,  0.0f, 1.0f};
    
    int in_count = 0;
    int index = 0;
    
    while (in_count < branch_count) {
        
       // printf("index: %d \n ", index);
        texture_buffer[index +0 ].x =1.0f;
        texture_buffer[index +0 ].y =1.0f;
        
        texture_buffer[index + 1].x =1.0f;
        texture_buffer[index + 1].y =0.0f;
        
        texture_buffer[index + 2].x =0.0f;
        texture_buffer[index + 2].y =0.0f;
        
        texture_buffer[index + 3].x =0.0f;
        texture_buffer[index + 3].y =1.0f;
        
        index = in_count * 4;
        in_count++;
        
    }

    
    //    texture_buffer[0].x =0.0f;
//    texture_buffer[0].y =1.0f;
//    
//    texture_buffer[1].x =0.0f;
//    texture_buffer[1].y =0.0f;
//    
//    texture_buffer[2].x =1.0f;
//    texture_buffer[2].y =1.0f;
//
//    texture_buffer[3].x =1.0f;
//    texture_buffer[3].y =1.0f;
    
//    texture_buffer[4].x =0.0f;
//    texture_buffer[4].y =0.0f;
//    
//    texture_buffer[5].x =1.0f;
//    texture_buffer[5].y =0.0f;

    // texture array buffer
    glGenBuffers(1,&cylinder_texture_VBO);
    glBindBuffer(GL_ARRAY_BUFFER,cylinder_texture_VBO);
//  glBufferData(GL_ARRAY_BUFFER,sizeof(glm::vec2) * 8 ,texture_buffer, GL_STATIC_DRAW);
    glBufferData(GL_ARRAY_BUFFER,sizeof(texture_buffer),texture_buffer, GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

}




void cylinder_buffer(){
    blind_texture();
    
    glGenVertexArrays(1, &cylinderVAO);
    glGenBuffers(1,&cylinderVBO);
    glGenBuffers(1,&cylinder_indices_VBO);
    
    glBindVertexArray(cylinderVAO);
    
    // positions of cylinder
    glBindBuffer(GL_ARRAY_BUFFER,cylinderVBO);
    glBufferData(GL_ARRAY_BUFFER,sizeof(buffer_cylinder),buffer_cylinder, GL_STATIC_DRAW);
   
    // cylinder indices buffer
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,cylinder_indices_VBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,sizeof(cylinder_indices) ,cylinder_indices, GL_STATIC_DRAW);
   
    
    //enable vertex array ----
    
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(GLfloat), (GLvoid*)0);
    
    glEnableVertexAttribArray(1);  // texture coords
    // Map index 1 to the texture coords buffer
    glBindBuffer(GL_ARRAY_BUFFER, cylinder_texture_VBO);
    glVertexAttribPointer( 1, 2, GL_FLOAT, GL_FALSE, 0,
                          (GLubyte *)NULL );
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    
}



void delete_buffers(){
    glDeleteBuffers(1, &sphereVAO);
    glDeleteBuffers(1, &sphereVBO);
    glDeleteBuffers(1, &sphere_downVAO);
    glDeleteBuffers(1, &sphere_downVBO);

    glDeleteBuffers(1, &cylinderVAO);
    glDeleteBuffers(1, &cylinderVBO);

    glDeleteBuffers(1, &cylinder_indices_VBO);
    glDeleteBuffers(1, &cylinder_texture_VBO);

    
}




